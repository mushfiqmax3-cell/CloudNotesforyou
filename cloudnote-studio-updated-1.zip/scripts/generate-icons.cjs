const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const publicDir = path.resolve(__dirname, '../public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// 1. Generate icon.svg
const svgContent = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" width="512" height="512">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#4F46E5" />
      <stop offset="50%" stop-color="#6366F1" />
      <stop offset="100%" stop-color="#7C3AED" />
    </linearGradient>
    <linearGradient id="bookGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FFFFFF" />
      <stop offset="100%" stop-color="#F1F5F9" />
    </linearGradient>
    <linearGradient id="cloudGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="#E0E7FF" stop-opacity="0.95" />
      <stop offset="100%" stop-color="#C7D2FE" stop-opacity="0.8" />
    </linearGradient>
    <linearGradient id="penGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#F59E0B" />
      <stop offset="100%" stop-color="#D97706" />
    </linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#1E1B4B" flood-opacity="0.45" />
    </filter>
    <filter id="softGlow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="4" stdDeviation="6" flood-color="#4338CA" flood-opacity="0.3" />
    </filter>
  </defs>

  <!-- Background Squircle -->
  <rect x="16" y="16" width="480" height="480" rx="108" fill="url(#bgGrad)" filter="url(#shadow)" />

  <!-- Inner Subtle Border -->
  <rect x="18" y="18" width="476" height="476" rx="106" fill="none" stroke="#FFFFFF" stroke-opacity="0.18" stroke-width="4" />

  <!-- Background Decorative Cloud (Top Left) -->
  <g opacity="0.3" transform="translate(68, 72) scale(0.65)">
    <path d="M120 70 A40 40 0 0 1 180 50 A55 55 0 0 1 260 75 A45 45 0 0 1 290 120 L80 120 A35 35 0 0 1 120 70 Z" fill="#FFFFFF" />
  </g>

  <!-- Main Notebook Body -->
  <g filter="url(#shadow)" transform="translate(106, 120)">
    <!-- Book Cover/Page Backing -->
    <rect x="0" y="0" width="300" height="300" rx="36" fill="url(#bookGrad)" />
    
    <!-- Spine Accent (Left stripe) -->
    <path d="M0 36 C0 16 16 0 36 0 L64 0 L64 300 L36 300 C16 300 0 284 0 264 Z" fill="#4338CA" />
    <!-- Spine binding stitches -->
    <line x1="32" y1="50" x2="32" y2="70" stroke="#818CF8" stroke-width="4" stroke-linecap="round" />
    <line x1="32" y1="110" x2="32" y2="130" stroke="#818CF8" stroke-width="4" stroke-linecap="round" />
    <line x1="32" y1="170" x2="32" y2="190" stroke="#818CF8" stroke-width="4" stroke-linecap="round" />
    <line x1="32" y1="230" x2="32" y2="250" stroke="#818CF8" stroke-width="4" stroke-linecap="round" />

    <!-- Notebook Text Lines -->
    <rect x="96" y="58" width="140" height="14" rx="7" fill="#6366F1" />
    <rect x="96" y="96" width="168" height="10" rx="5" fill="#94A3B8" opacity="0.75" />
    <rect x="96" y="126" width="148" height="10" rx="5" fill="#94A3B8" opacity="0.75" />
    <rect x="96" y="156" width="160" height="10" rx="5" fill="#94A3B8" opacity="0.75" />

    <!-- Cloud Stamp / Sync Badge on notebook -->
    <g transform="translate(96, 198)">
      <rect x="0" y="0" width="124" height="46" rx="23" fill="#EEF2FF" />
      <path d="M22 28 C22 22 27 18 33 18 C35 14 40 12 45 14 C48 11 53 12 56 15 C60 16 63 20 62 25 C66 26 67 30 65 33 C64 36 60 38 56 38 L24 38 C20 38 18 35 19 32 C20 30 21 29 22 28 Z" fill="#4F46E5" />
      <!-- Small check mark inside badge -->
      <path d="M76 28 L84 36 L102 18" fill="none" stroke="#10B981" stroke-width="4.5" stroke-linecap="round" stroke-linejoin="round" />
    </g>
  </g>

  <!-- Golden Modern Stylus/Pencil diagonally placed -->
  <g filter="url(#shadow)" transform="translate(325, 230) rotate(35)">
    <rect x="0" y="0" width="32" height="160" rx="10" fill="url(#penGrad)" />
    <!-- Pen band -->
    <rect x="0" y="30" width="32" height="12" fill="#FDE68A" />
    <!-- Nib -->
    <path d="M0 160 L16 195 L32 160 Z" fill="#1E293B" />
    <circle cx="16" cy="180" r="3" fill="#F59E0B" />
    <!-- Eraser/Top cap -->
    <rect x="0" y="0" width="32" height="20" rx="8" fill="#F43F5E" />
  </g>

  <!-- Sparkle / Star (Top Right) -->
  <g transform="translate(400, 72) scale(0.9)">
    <path d="M20 0 L26 14 L40 20 L26 26 L20 40 L14 26 L0 20 L14 14 Z" fill="#FDE047" opacity="0.95" />
  </g>
  <g transform="translate(75, 410) scale(0.6)">
    <path d="M20 0 L26 14 L40 20 L26 26 L20 40 L14 26 L0 20 L14 14 Z" fill="#A5B4FC" opacity="0.75" />
  </g>
</svg>`;

fs.writeFileSync(path.join(publicDir, 'icon.svg'), svgContent, 'utf8');
fs.writeFileSync(path.join(publicDir, 'favicon.svg'), svgContent, 'utf8');
console.log('Saved icon.svg and favicon.svg');

// 2. High Quality PNG generation functions using Node zlib
function crc32(buf) {
  let table = new Uint32Array(256);
  for (let i = 0; i < 256; i++) {
    let c = i;
    for (let k = 0; k < 8; k++) c = (c & 1) ? (0xedb88320 ^ (c >>> 1)) : (c >>> 1);
    table[i] = c;
  }
  let crc = 0 ^ (-1);
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ table[(crc ^ buf[i]) & 0xff];
  return (crc ^ (-1)) >>> 0;
}

function chunk(type, data) {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length, 0);
  const t = Buffer.from(type);
  const combined = Buffer.concat([t, data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(combined), 0);
  return Buffer.concat([len, combined, crc]);
}

function createPng(w, h, rgbaCallback) {
  const sig = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(w, 0);
  ihdr.writeUInt32BE(h, 4);
  ihdr[8] = 8; ihdr[9] = 6; ihdr[10] = 0; ihdr[11] = 0; ihdr[12] = 0;

  const scanlines = Buffer.alloc(h * (w * 4 + 1));
  let pos = 0;
  for (let y = 0; y < h; y++) {
    scanlines[pos++] = 0; // filter 0
    for (let x = 0; x < w; x++) {
      const [r, g, b, a] = rgbaCallback(x, y, w, h);
      scanlines[pos++] = r;
      scanlines[pos++] = g;
      scanlines[pos++] = b;
      scanlines[pos++] = a;
    }
  }
  const idat = chunk('IDAT', zlib.deflateSync(scanlines, { level: 9 }));
  const iend = chunk('IEND', Buffer.alloc(0));
  return Buffer.concat([sig, chunk('IHDR', ihdr), idat, iend]);
}

// Pixel shader for rendering the icon cleanly into PNG
function renderIconPixel(x, y, size, isMaskable = false) {
  const u = x / size;
  const v = y / size;

  if (isMaskable) {
    // Maskable icon: Android crops up to outer 15%. Safe zone is u, v in [0.15, 0.85]
    // Full bleed background gradient
    const t = (u + v) / 2;
    // Indigo-purple gradient: #4338CA (67, 56, 202) to #7C3AED (124, 58, 237)
    let bgR = Math.round(67 + (124 - 67) * t);
    let bgG = Math.round(56 + (58 - 56) * t);
    let bgB = Math.round(202 + (237 - 202) * t);

    // Inner scaled notebook centered in safe zone:
    const su = (u - 0.5) / 0.7 + 0.5;
    const sv = (v - 0.5) / 0.7 + 0.5;

    // Check if inside notebook: [0.24, 0.76] x [0.22, 0.78]
    if (su >= 0.24 && su <= 0.76 && sv >= 0.22 && sv <= 0.78) {
      // Rounded notebook page
      const cornerR = 0.05;
      const dx = Math.max(0, Math.abs(su - 0.5) - (0.26 - cornerR));
      const dy = Math.max(0, Math.abs(sv - 0.5) - (0.28 - cornerR));
      const dist = Math.sqrt(dx * dx + dy * dy);

      if (dist <= cornerR) {
        // Inside notebook
        // Spine on left: su in [0.24, 0.35]
        if (su <= 0.34) {
          return [67, 56, 202, 255]; // Deep Indigo spine
        }
        // Lines
        const lineY = [0.34, 0.44, 0.54, 0.64];
        for (const ly of lineY) {
          if (Math.abs(sv - ly) < 0.016 && su >= 0.40 && su <= 0.70) {
            return [99, 102, 241, 255]; // Indigo line
          }
        }
        // White page
        return [250, 252, 255, 255];
      }
    }

    // Pencil overlay in safe zone
    const pu = su - 0.65;
    const pv = sv - 0.65;
    if (Math.abs(pu + pv) < 0.05 && Math.abs(pu - pv) < 0.22) {
      return [245, 158, 11, 255]; // Amber pencil
    }

    return [bgR, bgG, bgB, 255];
  }

  // Standard non-maskable icon (Rounded Squircle with transparent corners)
  const squircleRadius = 0.22;
  const dx = Math.max(0, Math.abs(u - 0.5) - (0.46 - squircleRadius));
  const dy = Math.max(0, Math.abs(v - 0.5) - (0.46 - squircleRadius));
  const dist = Math.sqrt(dx * dx + dy * dy);

  if (dist > squircleRadius) {
    return [0, 0, 0, 0]; // Transparent outside squircle
  }

  // Background gradient: Indigo to Violet
  const t = (u + v) / 2;
  let r = Math.round(79 + (124 - 79) * t);
  let g = Math.round(70 + (58 - 70) * t);
  let b = Math.round(229 + (237 - 229) * t);

  // Notebook page inside: [0.22, 0.78] x [0.22, 0.78]
  const nbCorner = 0.06;
  const ndx = Math.max(0, Math.abs(u - 0.48) - (0.28 - nbCorner));
  const ndy = Math.max(0, Math.abs(v - 0.50) - (0.28 - nbCorner));
  const ndist = Math.sqrt(ndx * ndx + ndy * ndy);

  if (ndist <= nbCorner) {
    // Spine
    if (u <= 0.32) {
      return [67, 56, 202, 255]; // Spine
    }
    // Lines
    const lineY = [0.35, 0.45, 0.55, 0.65];
    for (const ly of lineY) {
      if (Math.abs(v - ly) < 0.016 && u >= 0.38 && u <= 0.72) {
        return [99, 102, 241, 255]; // Line
      }
    }
    // White sheet
    return [255, 255, 255, 255];
  }

  // Golden stylus pencil accent
  const pu = u - 0.68;
  const pv = v - 0.68;
  if (Math.abs(pu + pv) < 0.045 && Math.abs(pu - pv) < 0.25) {
    return [245, 158, 11, 255];
  }

  // Sparkle star (top right u: 0.8, v: 0.2)
  const starDist = Math.hypot(u - 0.8, v - 0.2);
  if (starDist < 0.04) {
    return [253, 224, 71, 255];
  }

  return [r, g, b, 255];
}

console.log('Generating PNGs...');

// 192x192
const png192 = createPng(192, 192, (x, y, s) => renderIconPixel(x, y, s, false));
fs.writeFileSync(path.join(publicDir, 'pwa-192x192.png'), png192);
console.log('Saved pwa-192x192.png');

// 512x512
const png512 = createPng(512, 512, (x, y, s) => renderIconPixel(x, y, s, false));
fs.writeFileSync(path.join(publicDir, 'pwa-512x512.png'), png512);
console.log('Saved pwa-512x512.png');

// 512x512 maskable (with safe zone margins)
const pngMaskable = createPng(512, 512, (x, y, s) => renderIconPixel(x, y, s, true));
fs.writeFileSync(path.join(publicDir, 'pwa-maskable-512x512.png'), pngMaskable);
console.log('Saved pwa-maskable-512x512.png');

// apple-touch-icon.png 180x180
const pngApple = createPng(180, 180, (x, y, s) => renderIconPixel(x, y, s, false));
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), pngApple);
console.log('Saved apple-touch-icon.png');

// favicon.ico (can be a 48x48 PNG saved or standard)
const pngFavicon = createPng(48, 48, (x, y, s) => renderIconPixel(x, y, s, false));
fs.writeFileSync(path.join(publicDir, 'favicon.ico'), pngFavicon);
console.log('Saved favicon.ico');

console.log('All icons generated successfully!');
