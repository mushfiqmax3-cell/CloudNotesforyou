import React, { useState, useEffect, useRef } from 'react';
import { onAuthStateChanged, signOut, updateProfile, updateEmail } from 'firebase/auth';
import {
  collection,
  doc,
  setDoc,
  deleteDoc,
  onSnapshot,
  query,
  where,
  getDoc,
  getDocs,
} from 'firebase/firestore';
import { ref, onValue, set as rtdbSet, remove as rtdbRemove } from 'firebase/database';
import { auth, db, rtdb } from './lib/firebase';
import {
  NoteItem,
  FolderItem,
  UserProfile,
  DEFAULT_FOLDERS,
  INITIAL_DEMO_NOTES,
  FontFamilyOption,
  combineSectionsToContent,
  getNormalizedSections,
} from './lib/types';
import { NoteEditor } from './components/NoteEditor';
import { NoteReaderView } from './components/NoteReaderView';
import { RecentNotesView } from './components/RecentNotesView';
import { ReadingModeModal } from './components/ReadingModeModal';
import { PWAInstallButton } from './components/PWAInstallButton';
import { LoginScreen } from './components/LoginScreen';
import { UserProfileSection } from './components/UserProfileSection';
import {
  Edit3,
  BookOpen,
  Clock,
  Folder as FolderIcon,
  Plus,
  Cloud,
  CloudOff,
  User,
  LogOut,
  Moon,
  Sun,
  Layers,
  ChevronRight,
  FolderPlus,
  SlidersHorizontal,
  FileText,
  Star,
  CheckCircle2,
  HardDriveDownload,
  Upload,
  Copy,
  Files,
} from 'lucide-react';

type NavigationTab = 'write' | 'recent' | 'favorites' | 'folders' | 'settings';

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [currentTab, setCurrentTab] = useState<NavigationTab>('write');

  // Notes & Folders State
  const [notes, setNotes] = useState<NoteItem[]>(INITIAL_DEMO_NOTES);
  const [folders, setFolders] = useState<FolderItem[]>(DEFAULT_FOLDERS);
  const [dataLoading, setDataLoading] = useState(false);
  const [activeNoteId, setActiveNoteId] = useState<string>(INITIAL_DEMO_NOTES[0].id);

  // Note View Mode State:
  // User Requirements:
  // 1. Normally kono note open korle Reading mode a Thakbe then user edit a click korle tokhon Edit mode a Jabe.
  // 3. Jokhon Kono user Kono new note creat Korbe tokhon Edit option theke suru hobe ar jokhon save kora file open Korbe tokhon Reading mode theke open hobe.
  const [noteViewMode, setNoteViewMode] = useState<'reading' | 'editing'>('reading');

  // New Note Draft State:
  // Requirement: "নতুন নোট তৈরি করুন অপশনে ক্লিক করলে একটি নতুন করে নোট লেখার অপশন আসবে সেটাকে সেই অপশন এ ক্লিক করলেই শুধুমাত্র সেভ হবে এছাড়া সেভ হবে না।"
  const [isCreatingNewDraft, setIsCreatingNewDraft] = useState(false);
  const [draftNote, setDraftNote] = useState<NoteItem | null>(null);

  // Reading Mode Modal State
  const [readingNote, setReadingNote] = useState<NoteItem | null>(null);
  const [readingModalOpen, setReadingModalOpen] = useState(false);

  // Appearance & customization
  const [darkMode, setDarkMode] = useState(false);
  const [fontFamily, setFontFamily] = useState<FontFamilyOption>('sans');
  const [isSaving, setIsSaving] = useState(false);
  const [lastSavedText, setLastSavedText] = useState('ক্লাউড সিঙ্ক প্রস্তুত');

  // Folder management
  const [selectedFolderId, setSelectedFolderId] = useState<string | null>(null);
  const [newFolderName, setNewFolderName] = useState('');
  const [showFolderInput, setShowFolderInput] = useState(false);

  // Feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 2500);
  };

  // Initialize theme and local cached notes on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('cloudnote_theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setDarkMode(true);
      document.documentElement.classList.add('dark');
    } else {
      setDarkMode(false);
      document.documentElement.classList.remove('dark');
    }

    const savedFont = localStorage.getItem('cloudnote_font') as FontFamilyOption | null;
    if (savedFont) setFontFamily(savedFont);

  }, []);

  // Listen to Firebase Authentication
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const profile: UserProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email,
          displayName: firebaseUser.displayName || firebaseUser.email?.split('@')[0] || 'User',
          creationTime: firebaseUser.metadata.creationTime,
          lastSignInTime: firebaseUser.metadata.lastSignInTime,
          phoneNumber: firebaseUser.phoneNumber || null,
        };
        setUser(profile);
      } else {
        setUser(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribeAuth();
  }, []);

  // Lazy data loading: only load the data required by the selected section.
  useEffect(() => {
    if (!user) return;

    let cancelled = false;
    let unsubscribe: (() => void) | undefined;

    const loadActiveNote = async () => {
      setDataLoading(true);
      try {
        if (!activeNoteId || activeNoteId.startsWith('demo-')) {
          const latestSnap = await getDocs(query(collection(db, 'notes'), where('userId', '==', user.uid)));
          const latest = latestSnap.docs
            .map((d) => d.data() as NoteItem)
            .sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0))[0];
          if (!cancelled && latest) {
            setNotes((prev) => [latest, ...prev.filter((n) => n.id !== latest.id)]);
            setActiveNoteId(latest.id);
          }
          return;
        }
        const snap = await getDoc(doc(db, 'notes', activeNoteId));
        if (!cancelled && snap.exists()) {
          const item = snap.data() as NoteItem;
          setNotes((prev) => [item, ...prev.filter((n) => n.id !== item.id)]);
        }
      } catch {
        // Local/offline state remains available.
      } finally {
        if (!cancelled) setDataLoading(false);
      }
    };

    const loadNotesForTab = () => {
      setDataLoading(true);
      const q = query(
        collection(db, 'notes'),
        where('userId', '==', user.uid)
      );
      unsubscribe = onSnapshot(q, (snapshot) => {
        const loaded = snapshot.docs.map((d) => d.data() as NoteItem).sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
        if (!cancelled) {
          setNotes(loaded);
          localStorage.setItem('cloudnote_cached_notes', JSON.stringify(loaded));
          if (!activeNoteId && loaded[0]) setActiveNoteId(loaded[0].id);
          setLastSavedText('অনলাইন ক্লাউডে সংরক্ষিত ✓');
          setDataLoading(false);
        }
      }, () => {
        if (!cancelled) setDataLoading(false);
      });
    };

    if (currentTab === 'recent' || currentTab === 'favorites' || currentTab === 'folders') {
      loadNotesForTab();
    } else if (currentTab === 'write') {
      loadActiveNote();
    }

    return () => {
      cancelled = true;
      if (unsubscribe) unsubscribe();
    };
  }, [user, currentTab, activeNoteId]);

  // Folders are loaded and watched only when the Folders section is opened.
  useEffect(() => {
    if (!user || currentTab !== 'folders') return;
    setDataLoading(true);
    const foldersRef = ref(rtdb, `users/${user.uid}/folders`);
    const unsubscribe = onValue(foldersRef, (snapshot) => {
      const val = snapshot.val();
      const loadedRemote = val && typeof val === 'object'
        ? (Object.values(val).filter(Boolean) as FolderItem[])
        : [];
      const defaultForUser = DEFAULT_FOLDERS.map((folder) => ({ ...folder, userId: user.uid }));
      const merged = [...defaultForUser, ...loadedRemote].filter(
        (folder, index, arr) => arr.findIndex((item) => item.id === folder.id) === index
      );
      setFolders(merged);
      localStorage.setItem('cloudnote_cached_folders', JSON.stringify(merged));
      if (loadedRemote.length === 0) {
        Promise.all(defaultForUser.map((folder) => rtdbSet(ref(rtdb, `users/${user.uid}/folders/${folder.id}`), folder))).catch(() => {});
      }
      setDataLoading(false);
    }, () => setDataLoading(false));
    return () => unsubscribe();
  }, [user, currentTab]);

  useEffect(() => {
    if (!user || currentTab !== 'settings') return;
    const profileRef = ref(rtdb, `users/${user.uid}/profile`);
    const unsubscribe = onValue(profileRef, (snapshot) => {
      const profile = snapshot.val();
      if (profile && typeof profile === 'object') {
        setUser((prev) => prev ? {
          ...prev,
          displayName: profile.name ?? prev.displayName,
          email: profile.email ?? prev.email,
          phoneNumber: profile.phoneNumber ?? prev.phoneNumber,
        } : prev);
      }
    });
    return () => unsubscribe();
  }, [user?.uid, currentTab]);

  // Dark Mode Toggle
  const toggleDarkMode = () => {
    const next = !darkMode;
    setDarkMode(next);
    if (next) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('cloudnote_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('cloudnote_theme', 'light');
    }
  };

  // User Requirements:
  // 1. Normally kono note open korle Reading mode a Thakbe then user edit a click korle tokhon Edit mode a Jabe.
  // 3. Jokhon Kono user Kono new note creat Korbe tokhon Edit option theke suru hobe ar jokhon save kora file open Korbe tokhon Reading mode theke open hobe.

  // Create new note: starts directly in EDIT mode!
  const handleStartCreateNewNote = (folderTarget?: string) => {
    const freshDraft: NoteItem = {
      id: 'note_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7),
      userId: user?.uid || 'local',
      title: '',
      content: '',
      sections: [
        {
          id: 'sec_' + Date.now(),
          title: '১ম অধ্যায় / মূল অংশ',
          content: '',
        },
      ],
      category: 'ব্যক্তিগত (Personal)',
      folderId: folderTarget || selectedFolderId || 'general',
      isPinned: false,
      isFavorite: false,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      synced: false,
    };
    setDraftNote(freshDraft);
    setIsCreatingNewDraft(true);
    setNoteViewMode('editing'); // Starts in edit mode!
    setCurrentTab('write');
  };

  // Open any saved note: normally opens in READING mode!
  const handleOpenSavedNote = (note: NoteItem, startInEditMode = false) => {
    setIsCreatingNewDraft(false);
    setDraftNote(null);
    setActiveNoteId(note.id);
    setNoteViewMode(startInEditMode ? 'editing' : 'reading'); // Saved notes open in reading mode!
    setCurrentTab('write');
  };

  // Cancel new note draft without saving: returns to reading mode
  const handleCancelNewDraft = () => {
    setIsCreatingNewDraft(false);
    setDraftNote(null);
    setNoteViewMode('reading');
  };

  // Save Note: persists and returns to Reading Mode for the saved note
  const handleSaveNote = async (noteToSave: NoteItem) => {
    setIsSaving(true);

    const isDraft = isCreatingNewDraft;
    setIsCreatingNewDraft(false);
    setDraftNote(null);
    setActiveNoteId(noteToSave.id);
    setNoteViewMode('reading'); // After save, transitions to Reading Mode!

    // Update state & local storage
    setNotes((prev) => {
      const exists = prev.some((n) => n.id === noteToSave.id);
      const updated = exists
        ? prev.map((n) => (n.id === noteToSave.id ? noteToSave : n))
        : [noteToSave, ...prev];
      localStorage.setItem('cloudnote_cached_notes', JSON.stringify(updated));
      return updated;
    });

    // Save to Firestore Online Cloud & Realtime Database if user is authenticated
    if (user) {
      const dataToSave = {
        ...noteToSave,
        userId: user.uid,
        userEmail: user.email,
        email: user.email,
        synced: true,
      };

      // 1. Save to Firestore
      try {
        await setDoc(doc(db, 'notes', noteToSave.id), dataToSave);
      } catch (err) {
        console.warn('Firestore save notice:', err);
      }

      // 2. Save to Realtime Database
      try {
        await rtdbSet(ref(rtdb, `users/${user.uid}/notes/${noteToSave.id}`), dataToSave);
      } catch (err) {
        console.warn('RTDB user save notice:', err);
      }
      try {
        await rtdbSet(ref(rtdb, `notes/${noteToSave.id}`), dataToSave);
      } catch (err) {
        console.warn('RTDB root save notice:', err);
      }

      setLastSavedText('অনলাইন ক্লাউডে সেভ হয়েছে ✓');
    } else {
      setLastSavedText('ডিভাইসে সেভ হয়েছে (ক্লাউড সিঙ্কের জন্য লগইন করুন)');
    }

    setIsSaving(false);
    showToast(isDraft ? 'নতুন নোট সফলভাবে সেভ হয়েছে!' : 'নোট সেভ সম্পন্ন হয়েছে!');
  };

  // Toggle Favorite
  const handleToggleFavorite = async (noteToToggle: NoteItem) => {
    const nextFav = !noteToToggle.isFavorite;
    const updatedNote: NoteItem = { ...noteToToggle, isFavorite: nextFav, updatedAt: Date.now() };

    setNotes((prev) => {
      const updated = prev.map((n) => (n.id === noteToToggle.id ? updatedNote : n));
      localStorage.setItem('cloudnote_cached_notes', JSON.stringify(updated));
      return updated;
    });

    if (user) {
      try {
        await setDoc(doc(db, 'notes', updatedNote.id), updatedNote);
      } catch {
        // offline
      }
    }
    showToast(nextFav ? 'ফেভারিটে যোগ করা হয়েছে ⭐' : 'ফেভারিট থেকে সরানো হয়েছে');
  };

  // Special Feature: 1-Click Clone / Duplicate Note
  const handleDuplicateNote = (item: NoteItem) => {
    const clonedSections = getNormalizedSections(item).map((s, idx) => ({
      ...s,
      id: `sec_${Date.now()}_${idx}`,
    }));
    const dupNote: NoteItem = {
      ...item,
      id: 'note_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      title: `${item.title || 'নোট'} (কপি)`,
      sections: clonedSections,
      content: combineSectionsToContent(clonedSections),
      createdAt: Date.now(),
      updatedAt: Date.now(),
      synced: false,
    };
    handleSaveNote(dupNote);
    showToast('নোটটি সফলভাবে ক্লোন/কপি করা হয়েছে!');
  };

  // Special Feature: Export Full Backup JSON
  const handleExportBackup = () => {
    const backupData = {
      version: 2,
      exportDate: new Date().toISOString(),
      notes,
      folders,
    };
    const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cloudnote_backup_${new Date().toISOString().slice(0, 10)}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('সম্পূর্ণ ব্যাকআপ ফাইল ডাউনলোড সম্পন্ন হয়েছে!');
  };

  // Special Feature: Import Backup JSON
  const handleImportBackup = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(String(event.target?.result || '{}'));
        if (Array.isArray(parsed.notes)) {
          const mergedNotes = [...parsed.notes, ...notes].filter(
            (v, i, arr) => arr.findIndex((t) => t.id === v.id) === i
          );
          setNotes(mergedNotes);
          localStorage.setItem('cloudnote_cached_notes', JSON.stringify(mergedNotes));
        }
        if (Array.isArray(parsed.folders)) {
          const mergedFolders = [...folders, ...parsed.folders].filter(
            (v, i, arr) => arr.findIndex((t) => t.id === v.id) === i
          );
          setFolders(mergedFolders);
          localStorage.setItem('cloudnote_cached_folders', JSON.stringify(mergedFolders));
        }
        showToast('ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!');
      } catch {
        showToast('ব্যাকআপ ফাইলটি সঠিক নয়।');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Delete Note
  const handleDeleteNote = async (idToDelete: string) => {
    const filtered = notes.filter((n) => n.id !== idToDelete);
    setNotes(filtered);
    localStorage.setItem('cloudnote_cached_notes', JSON.stringify(filtered));

    if (activeNoteId === idToDelete && filtered.length > 0) {
      setActiveNoteId(filtered[0].id);
    }

    if (user) {
      try {
        await deleteDoc(doc(db, 'notes', idToDelete));
      } catch {
        // offline
      }
      try {
        await rtdbRemove(ref(rtdb, `users/${user.uid}/notes/${idToDelete}`));
        await rtdbRemove(ref(rtdb, `notes/${idToDelete}`));
      } catch {
        // offline
      }
    }
    showToast('নোট মুছে ফেলা হয়েছে');
  };

  // Create Folder
  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFolderName.trim()) return;
    const newFolder: FolderItem = {
      id: 'folder_' + Date.now(),
      userId: user?.uid || 'local',
      name: newFolderName.trim(),
      color: 'indigo' as unknown as FolderItem['color'],
      createdAt: Date.now(),
    };
    const updated = [...folders, newFolder];
    setFolders(updated);
    localStorage.setItem('cloudnote_cached_folders', JSON.stringify(updated));
    if (user) {
      try {
        await rtdbSet(ref(rtdb, `users/${user.uid}/folders/${newFolder.id}`), newFolder);
      } catch {
        showToast('ফোল্ডারটি ডিভাইসে সেভ হয়েছে; ক্লাউড সিঙ্ক পরে হবে।');
      }
    }
    setNewFolderName('');
    setShowFolderInput(false);
    showToast('নতুন ফোল্ডার তৈরি হয়েছে!');
  };

  const handleSaveProfile = async (name: string, email: string, phone: string) => {
    if (!user) return;
    const firebaseUser = auth.currentUser;
    if (!firebaseUser) return;
    try {
      if (name.trim() && name.trim() !== (firebaseUser.displayName || '')) {
        await updateProfile(firebaseUser, { displayName: name.trim() });
      }
      if (email.trim() && email.trim() !== (firebaseUser.email || '')) {
        await updateEmail(firebaseUser, email.trim());
      }
      await rtdbSet(ref(rtdb, `users/${user.uid}/profile`), {
        name: name.trim(),
        email: email.trim(),
        phoneNumber: phone.trim(),
        updatedAt: Date.now(),
      });
      setUser((prev) => prev ? { ...prev, displayName: name.trim(), email: email.trim(), phoneNumber: phone.trim() } : prev);
      showToast('প্রোফাইল সফলভাবে আপডেট হয়েছে ✓');
    } catch (error) {
      console.warn('Profile update:', error);
      showToast('ইমেইল আপডেট করতে পুনরায় লগইন প্রয়োজন হতে পারে।');
    }
  };

  // Sign out
  const handleSignOut = async () => {
    await signOut(auth);
    setUser(null);
    showToast('লগআউট করা হয়েছে।');
  };

  // Active note to display in write tab
  const currentActiveNote = isCreatingNewDraft
    ? draftNote!
    : notes.find((n) => n.id === activeNoteId) || notes[0] || INITIAL_DEMO_NOTES[0];

  // Loading state while Firebase verifies user session
  if (authLoading) {
    return (
      <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-[#F4F6FA] dark:bg-slate-950 flex flex-col items-center justify-center space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-indigo-600 text-white flex items-center justify-center shadow-xl shadow-indigo-600/30 animate-pulse">
            <FileText className="h-7 w-7" />
          </div>
          <p className="text-xs font-bold text-slate-500 dark:text-slate-400">
            ক্লাউড অ্যাকাউন্টে কানেক্ট হচ্ছে...
          </p>
        </div>
      </div>
    );
  }

  // User Requirement: "Akhon Note ta open korle age login interface ta age ashbe then user Log in korle sob data firebase database a store hobe...."
  if (!user) {
    return (
      <div className={darkMode ? 'dark' : ''}>
        <LoginScreen
          onLoginSuccess={(profile) => {
            setUser(profile);
            showToast(`স্বাগতম ${profile.displayName}`);
          }}
          darkMode={darkMode}
          onToggleDarkMode={toggleDarkMode}
        />
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${darkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-[#F4F6FA] dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col transition-colors duration-200">
        {/* Toast feedback */}
        {toastMessage && (
          <div className="fixed top-4 right-4 z-50 bg-slate-900 dark:bg-white text-white dark:text-slate-900 px-4 py-2 rounded-2xl shadow-xl text-xs font-bold flex items-center gap-2 animate-bounce">
            <CheckCircle2 className="h-4 w-4 text-emerald-400 dark:text-emerald-600" />
            <span>{toastMessage}</span>
          </div>
        )}

        {/* Top Navbar */}
        <header className="sticky top-0 z-40 bg-white/85 dark:bg-slate-900/85 backdrop-blur-md border-b border-slate-200/80 dark:border-slate-800 px-4 sm:px-8 py-2.5 sm:py-3">
          <div className="max-w-6xl mx-auto flex items-center justify-between gap-3">
            {/* Logo */}
            <div
              onClick={() => {
                setIsCreatingNewDraft(false);
                setNoteViewMode('reading');
                setCurrentTab('write');
              }}
              className="flex items-center gap-2 cursor-pointer select-none"
            >
              <div className="p-2 rounded-xl bg-indigo-600 text-white shadow-xs">
                <FileText className="h-4 w-4" />
              </div>
              <div>
                <span className="text-base sm:text-lg font-black tracking-tight text-slate-900 dark:text-white">
                  CloudNote Studio
                </span>
                <span className="hidden sm:inline-block ml-2 px-2 py-0.5 rounded-full bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400 text-[10px] font-bold">
                  অনলাইন ক্লাউড
                </span>
              </div>
            </div>

            {/* Action Buttons: PWA Install + New Note + User Profile + Theme */}
            <div className="flex items-center gap-2 sm:gap-2.5">
              {/* PWA App Install Button (Google Chrome & mobile download support) */}
              <PWAInstallButton compact />

              {/* Requirement: New Note creation button (starts in EDIT mode) */}
              <button
                type="button"
                onClick={() => handleStartCreateNewNote()}
                className="flex items-center gap-1.5 px-3 py-1.5 sm:px-3.5 sm:py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold shadow-xs transition-all active:scale-95 cursor-pointer whitespace-nowrap"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>নতুন নোট</span>
              </button>

              {/* Theme toggle */}
              <button
                type="button"
                onClick={toggleDarkMode}
                className="p-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-amber-300 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors"
                title={darkMode ? 'লাইট মোড' : 'ডার্ক মোড'}
              >
                {darkMode ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
              </button>

            </div>
          </div>
        </header>

        {/* Main Content Area */}
        <main className="flex-1 max-w-6xl w-full mx-auto px-3.5 sm:px-6 py-5 pb-24">
          {dataLoading && <div className="mb-3 text-[11px] font-semibold text-slate-400">ডেটা লোড হচ্ছে…</div>}
          {/* TAB 1: ACTIVE NOTE VIEW (READING MODE BY DEFAULT / EDIT MODE ON DEMAND) */}
          {currentTab === 'write' && currentActiveNote && (
            <div className="space-y-4">
              {noteViewMode === 'reading' && !isCreatingNewDraft ? (
                <NoteReaderView
                  note={currentActiveNote}
                  folders={folders}
                  fontFamily={fontFamily}
                  onEnterEditMode={() => setNoteViewMode('editing')}
                  onToggleFavorite={handleToggleFavorite}
                  onOpenFullScreenReading={() => {
                    setReadingNote(currentActiveNote);
                    setReadingModalOpen(true);
                  }}
                />
              ) : (
                <NoteEditor
                  note={currentActiveNote}
                  folders={folders}
                  isNewDraft={isCreatingNewDraft}
                  onSave={handleSaveNote}
                  onCancelDraft={handleCancelNewDraft}
                  onDelete={handleDeleteNote}
                  onSwitchToReadingMode={() => setNoteViewMode('reading')}
                  fontFamily={fontFamily}
                  isSaving={isSaving}
                  lastSavedText={lastSavedText}
                />
              )}
            </div>
          )}

          {/* TAB 2: RECENT SAVED NOTES (Opens in Reading Mode by default) */}
          {currentTab === 'recent' && (
            <RecentNotesView
              notes={notes}
              folders={folders}
              defaultFilter="all"
              onSelectNote={(note) => {
                handleOpenSavedNote(note, false); // Opens in Reading mode!
              }}
              onEditNote={(note) => {
                handleOpenSavedNote(note, true); // Direct Edit mode option
              }}
              onDeleteNote={handleDeleteNote}
              onToggleFavorite={handleToggleFavorite}
              onOpenReadingMode={(note) => {
                setReadingNote(note);
                setReadingModalOpen(true);
              }}
            />
          )}

          {/* TAB 3: FAVORITES TAB */}
          {currentTab === 'favorites' && (
            <RecentNotesView
              notes={notes}
              folders={folders}
              defaultFilter="favorite"
              onSelectNote={(note) => {
                handleOpenSavedNote(note, false); // Opens in Reading mode!
              }}
              onEditNote={(note) => {
                handleOpenSavedNote(note, true); // Direct Edit mode option
              }}
              onDeleteNote={handleDeleteNote}
              onToggleFavorite={handleToggleFavorite}
              onOpenReadingMode={(note) => {
                setReadingNote(note);
                setReadingModalOpen(true);
              }}
            />
          )}

          {/* TAB 4: FOLDERS VIEW (Medium-sized compact cards)
              Requirement: "ফোল্ডারের সাইজ এবং রিসেন্ট অপশনে থাকা নোটগুলোকে একটু মাঝারি করে দেখাবে যেন এক স্ক্রিনে অনেক গুলো স্ক্রিনে দেখতে পাই।"
          */}
          {currentTab === 'folders' && (
            <div className="space-y-4">
              <div className="rounded-2xl bg-white dark:bg-slate-900 p-4 sm:p-5 border border-slate-200/80 dark:border-slate-800 shadow-sm flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                    নোট ফোল্ডারসমূহ (Folders)
                  </h2>
                  <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                    মাঝারি সাইজের ফোল্ডার কার্ডে এক নজরে সব ফোল্ডার ও সংরক্ষিত নোট দেখুন
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowFolderInput(!showFolderInput)}
                  className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer"
                >
                  <FolderPlus className="h-4 w-4" />
                  <span>+ নতুন ফোল্ডার</span>
                </button>
              </div>

              {/* Add folder form */}
              {showFolderInput && (
                <form
                  onSubmit={handleCreateFolder}
                  className="rounded-2xl bg-white dark:bg-slate-900 p-3.5 border border-indigo-200 dark:border-indigo-900 flex flex-wrap items-center gap-2.5"
                >
                  <input
                    type="text"
                    value={newFolderName}
                    onChange={(e) => setNewFolderName(e.target.value)}
                    placeholder="ফোল্ডারের নাম লিখুন..."
                    className="flex-1 min-w-[200px] px-3.5 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-indigo-600"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold cursor-pointer"
                  >
                    সেভ করুন
                  </button>
                </form>
              )}

              {/* Medium Compact Folders Grid: 2 cols on mobile, 3 on tablet, 4-5 on desktop! */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
                {folders.map((f) => {
                  const folderNotes = notes.filter((n) => n.folderId === f.id);
                  const isSelected = selectedFolderId === f.id;

                  return (
                    <div
                      key={f.id}
                      onClick={() => setSelectedFolderId(isSelected ? null : f.id)}
                      className={`group rounded-2xl p-3.5 border transition-all cursor-pointer flex flex-col justify-between space-y-2 ${
                        isSelected
                          ? 'bg-indigo-50 dark:bg-indigo-950/40 border-indigo-500 shadow-sm ring-1 ring-indigo-500'
                          : 'bg-white dark:bg-slate-900 border-slate-200/80 dark:border-slate-800 hover:border-indigo-400 shadow-2xs'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="p-2 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400">
                          <FolderIcon className="h-5 w-5" />
                        </div>
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-lg bg-slate-100 dark:bg-slate-800 tabular-nums">
                          {folderNotes.length} নোট
                        </span>
                      </div>
                      <div>
                        <h3 className="text-xs sm:text-sm font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 truncate">
                          {f.name.split(' (')[0]}
                        </h3>
                        <p className="text-[10px] text-slate-400 truncate mt-0.5">
                          {isSelected ? 'নোটের তালিকা সক্রিয়' : 'ক্লিক করে দেখুন'}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Selected folder notes list */}
              {selectedFolderId && (
                <div className="mt-4 rounded-2xl bg-white dark:bg-slate-900 p-4 sm:p-5 border border-indigo-200 dark:border-indigo-900 space-y-2.5">
                  <div className="flex items-center justify-between pb-2.5 border-b border-slate-100 dark:border-slate-800">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                      {folders.find((f) => f.id === selectedFolderId)?.name || 'ফোল্ডার'}-এর সকল নোট
                    </h3>
                    <button
                      type="button"
                      onClick={() => handleStartCreateNewNote(selectedFolderId)}
                      className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-indigo-600 text-white text-xs font-bold cursor-pointer"
                    >
                      <Plus className="h-3 w-3" />
                      <span>এই ফোল্ডারে নতুন নোট</span>
                    </button>
                  </div>
                  {notes.filter((n) => n.folderId === selectedFolderId).length === 0 ? (
                    <p className="text-xs text-slate-400 py-3 text-center">
                      এই ফোল্ডারে এখনো কোনো নোট নেই।
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
                      {notes
                        .filter((n) => n.folderId === selectedFolderId)
                        .map((item) => (
                          <div
                            key={item.id}
                            onClick={() => {
                              handleOpenSavedNote(item, false); // Opens in Reading mode!
                            }}
                            className="p-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 hover:bg-indigo-50 dark:hover:bg-slate-800 border border-slate-200/70 dark:border-slate-700/60 flex items-center justify-between cursor-pointer transition-colors"
                          >
                            <div className="truncate mr-2">
                              <div className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100 truncate">
                                {item.title || 'শিরোনামহীন নোট'}
                              </div>
                              <div className="text-[11px] text-slate-400 truncate mt-0.5">
                                {item.content.slice(0, 60) || '(খালি)'}
                              </div>
                            </div>
                            <ChevronRight className="h-4 w-4 text-slate-400 shrink-0" />
                          </div>
                        ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* TAB 5: SETTINGS & BACKUP */}
          {currentTab === 'settings' && (
            <div className="rounded-2xl bg-white dark:bg-slate-900 p-5 sm:p-7 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-6">
              <div>
                <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
                  সেটিংস ও ব্যাকআপ (Settings & Backup)
                </h2>
                <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
                  ক্লাউড অ্যাকাউন্ট স্ট্যাটাস, মোবাইল অ্যাপ ডাউনলোড, ফন্ট এবং সম্পূর্ণ ডেটা ব্যাকআপ
                </p>
              </div>

              {/* Requirement: User Profile Option & Details in Settings, with Log out button */}
              <UserProfileSection
                user={user}
                onSignOut={handleSignOut}
                onSaveProfile={handleSaveProfile}
              />

              {/* Special Feature: One-Click Full JSON Backup & Restore */}
              <div className="p-4 sm:p-5 rounded-2xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200/80 dark:border-slate-700/80 space-y-3">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                      সম্পূর্ণ নোট ব্যাকআপ ও রিস্টোর (1-Click Data Safety)
                    </h3>
                    <p className="text-xs text-slate-500 mt-0.5">
                      আপনার সমস্ত অধ্যায়, নোট ও ফোল্ডার এক ক্লিকে ডাউনলোড করে রাখুন অথবা পূর্বের ফাইল আপলোড করুন।
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2 pt-1">
                  <button
                    type="button"
                    onClick={handleExportBackup}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900 dark:bg-indigo-600 text-white text-xs font-bold hover:bg-slate-800 transition-all cursor-pointer"
                  >
                    <HardDriveDownload className="h-3.5 w-3.5" />
                    <span>সব নোট ডাউনলোড (Backup)</span>
                  </button>

                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".json"
                    onChange={handleImportBackup}
                    className="hidden"
                  />
                  <button
                    type="button"
                    onClick={() => fileInputRef.current?.click()}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 text-xs font-bold hover:bg-slate-100 transition-all cursor-pointer"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    <span>ব্যাকআপ ফাইল আপলোড (Restore)</span>
                  </button>
                </div>
              </div>

              {/* Font Style Selection */}
              <div className="space-y-2">
                <label className="text-xs font-bold text-slate-600 dark:text-slate-300">
                  লেখার ফন্ট পরিবার (Font Family):
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
                  {(['sans', 'serif', 'mono', 'noto-sans-bengali', 'solaiman-lipi', 'kalpurush', 'hind-siliguri', 'noto-serif-bengali', 'tiro-bangla', 'georgia', 'times-new-roman'] as FontFamilyOption[]).map((f) => (
                    <button
                      key={f}
                      type="button"
                      onClick={() => {
                        setFontFamily(f);
                        localStorage.setItem('cloudnote_font', f);
                      }}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition-all cursor-pointer ${
                        fontFamily === f
                          ? 'border-indigo-600 bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400'
                          : 'border-slate-200 dark:border-slate-800 hover:bg-slate-50'
                      }`}
                    >
                      {{sans:'Sans-Serif',serif:'Serif',mono:'Monospace','noto-sans-bengali':'Noto Sans Bengali','solaiman-lipi':'SolaimanLipi','kalpurush':'Kalpurush','hind-siliguri':'Hind Siliguri','noto-serif-bengali':'Noto Serif Bengali','tiro-bangla':'Tiro Bangla',georgia:'Georgia','times-new-roman':'Times New Roman'} as Record<FontFamilyOption,string>}[f]
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </main>

        {/* Floating Bottom Navigation Bar with Direct FAVORITES Tab */}
        <div className="fixed bottom-4 left-1/2 -translate-x-1/2 z-40 w-auto max-w-[96%]">
          <nav
            aria-label="Bottom Navigation"
            className="rounded-full bg-white/90 dark:bg-slate-900/90 backdrop-blur-xl shadow-xl border border-slate-200/80 dark:border-slate-800 p-1.5 flex items-center gap-1"
          >
            {/* Note Workspace Tab (Reading Mode / Edit Mode toggle) */}
            <button
              type="button"
              onClick={() => {
                setIsCreatingNewDraft(false);
                if (currentTab === 'write') {
                  setNoteViewMode((prev) => (prev === 'reading' ? 'editing' : 'reading'));
                } else {
                  setCurrentTab('write');
                }
              }}
              className={`flex items-center gap-1.5 px-3.5 py-2 sm:px-4 sm:py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                currentTab === 'write'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              {noteViewMode === 'editing' && !isCreatingNewDraft ? (
                <>
                  <Edit3 className="h-3.5 w-3.5" />
                  <span>এডিটর মোড</span>
                </>
              ) : (
                <>
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>রিডিং মোড</span>
                </>
              )}
            </button>

            {/* Recent */}
            <button
              type="button"
              onClick={() => {
                setIsCreatingNewDraft(false);
                setCurrentTab('recent');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                currentTab === 'recent'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Clock className="h-3.5 w-3.5" />
              <span>রিসেন্ট</span>
            </button>

            {/* Requirement: FAVORITES Tab Restored */}
            <button
              type="button"
              onClick={() => {
                setIsCreatingNewDraft(false);
                setCurrentTab('favorites');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                currentTab === 'favorites'
                  ? 'bg-rose-500 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Star className="h-3.5 w-3.5 fill-current" />
              <span>ফেভারিট ({notes.filter((n) => n.isFavorite).length})</span>
            </button>

            {/* Folders */}
            <button
              type="button"
              onClick={() => {
                setIsCreatingNewDraft(false);
                setCurrentTab('folders');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                currentTab === 'folders'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <Layers className="h-3.5 w-3.5" />
              <span>ফোল্ডার</span>
            </button>

            {/* Settings */}
            <button
              type="button"
              onClick={() => {
                setIsCreatingNewDraft(false);
                setCurrentTab('settings');
              }}
              className={`flex items-center gap-1.5 px-3 py-2 sm:px-3.5 sm:py-2.5 rounded-full text-xs font-bold transition-all cursor-pointer whitespace-nowrap ${
                currentTab === 'settings'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
              }`}
            >
              <SlidersHorizontal className="h-3.5 w-3.5" />
              <span className="hidden sm:inline">সেটিংস</span>
            </button>
          </nav>
        </div>

        {/* Dedicated Full Screen Clean Reading Mode Modal */}
        {readingNote && (
          <ReadingModeModal
            note={readingNote}
            isOpen={readingModalOpen}
            onClose={() => {
              setReadingModalOpen(false);
              setReadingNote(null);
            }}
          />
        )}
      </div>
    </div>
  );
}
