import React from 'react';
import { Download, CheckCircle } from 'lucide-react';
import { usePWAInstall } from '../hooks/usePWAInstall';

export const PWAInstallButton: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { isInstallable, isInstalled, install } = usePWAInstall();

  // If already installed, hide
  if (isInstalled) {
    return (
      <div className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 text-[11px] font-bold">
        <CheckCircle className="h-3.5 w-3.5" />
        <span>অ্যাপ সক্রিয়</span>
      </div>
    );
  }

  // Only show when the browser triggers installability (e.g. Chrome)
  if (!isInstallable) {
    return null;
  }

  const handleInstallClick = async () => {
    await install();
  };

  return (
    <button
      type="button"
      onClick={handleInstallClick}
      className={`flex items-center gap-1.5 rounded-xl font-bold transition-all cursor-pointer shadow-xs active:scale-95 ${
        compact
          ? 'px-2.5 py-1.5 text-xs bg-indigo-600 hover:bg-indigo-500 text-white'
          : 'px-3 py-1.5 sm:px-3.5 sm:py-2 text-xs bg-indigo-600 hover:bg-indigo-500 text-white'
      }`}
      title="অ্যাপ হিসেবে ইনস্টল করুন"
    >
      <Download className="h-3.5 w-3.5" />
      <span className="hidden xs:inline sm:inline">অ্যাপ ইনস্টল</span>
      <span className="xs:hidden sm:hidden">ইনস্টল</span>
    </button>
  );
};
