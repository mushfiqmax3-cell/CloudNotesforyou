import React, { useState } from 'react';
import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
} from 'firebase/auth';
import { auth } from '../lib/firebase';
import {
  Lock,
  Mail,
  User as UserIcon,
  ArrowRight,
  AlertCircle,
  Eye,
  EyeOff,
  Cloud,
  CheckCircle2,
  FileText,
  KeyRound,
  ShieldCheck,
  Smartphone,
  BookOpen,
} from 'lucide-react';
import { UserProfile } from '../lib/types';

interface LoginScreenProps {
  onLoginSuccess: (profile: UserProfile) => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
}

export const LoginScreen: React.FC<LoginScreenProps> = ({
  onLoginSuccess,
  darkMode,
  onToggleDarkMode,
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'forgot'>('login');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg(null);
    setSuccessMsg(null);

    const cleanEmail = email.trim();
    const cleanPassword = password.trim();

    if (!cleanEmail) {
      setErrorMsg('অনুগ্রহ করে আপনার ইমেইল প্রদান করুন।');
      return;
    }

    if (mode === 'forgot') {
      setLoading(true);
      try {
        await sendPasswordResetEmail(auth, cleanEmail);
        setSuccessMsg('পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে। অনুগ্রহ করে ইনবক্স চেক করুন।');
      } catch (err: unknown) {
        setErrorMsg((err as Error)?.message || 'পাসওয়ার্ড রিসেট করতে সমস্যা হয়েছে।');
      } finally {
        setLoading(false);
      }
      return;
    }

    if (!cleanPassword) {
      setErrorMsg('অনুগ্রহ করে পাসওয়ার্ড দিন।');
      return;
    }

    if (cleanPassword.length < 6) {
      setErrorMsg('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে।');
      return;
    }

    setLoading(true);
    try {
      if (mode === 'register') {
        const cred = await createUserWithEmailAndPassword(auth, cleanEmail, cleanPassword);
        if (name.trim()) {
          await updateProfile(cred.user, { displayName: name.trim() });
        }
        const profile: UserProfile = {
          uid: cred.user.uid,
          email: cred.user.email,
          displayName: name.trim() || cred.user.displayName || cleanEmail.split('@')[0],
          creationTime: cred.user.metadata.creationTime,
          lastSignInTime: cred.user.metadata.lastSignInTime,
        };
        setSuccessMsg('অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে! ক্লাউড ডাটাবেজের সাথে কানেক্ট করা হচ্ছে...');
        setTimeout(() => {
          onLoginSuccess(profile);
        }, 600);
      } else {
        const cred = await signInWithEmailAndPassword(auth, cleanEmail, cleanPassword);
        const profile: UserProfile = {
          uid: cred.user.uid,
          email: cred.user.email,
          displayName: cred.user.displayName || cleanEmail.split('@')[0],
          creationTime: cred.user.metadata.creationTime,
          lastSignInTime: cred.user.metadata.lastSignInTime,
        };
        setSuccessMsg('সফলভাবে লগইন হয়েছে! আপনার নোটগুলো লোড হচ্ছে...');
        setTimeout(() => {
          onLoginSuccess(profile);
        }, 600);
      }
    } catch (err: unknown) {
      const code = (err as { code?: string })?.code || '';
      if (code === 'auth/invalid-credential' || code === 'auth/wrong-password' || code === 'auth/user-not-found') {
        setErrorMsg('ইমেইল অথবা পাসওয়ার্ড সঠিক নয়। নতুন একাউন্ট খুলতে "নতুন একাউন্ট" সিলেক্ট করুন।');
      } else if (code === 'auth/email-already-in-use') {
        setErrorMsg('এই ইমেইল দিয়ে ইতিপূর্বে একাউন্ট খোলা হয়েছে। অনুগ্রহ করে "লগইন" সিলেক্ট করে প্রবেশ করুন।');
      } else if (code === 'auth/invalid-email') {
        setErrorMsg('ইমেইলের ফরম্যাট সঠিক নয় (যেমন: example@gmail.com)।');
      } else if (code === 'auth/network-request-failed') {
        setErrorMsg('ইন্টারনেট সংযোগ চেক করুন। নেটওয়ার্কে সমস্যা হচ্ছে।');
      } else {
        setErrorMsg((err as Error)?.message || 'লগইন করতে সমস্যা হচ্ছে। কিছুক্ষণ পর আবার চেষ্টা করুন।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F6FA] dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex flex-col justify-center items-center px-4 py-8 selection:bg-indigo-600 selection:text-white">
      {/* Top Floating App Branding */}
      <div className="w-full max-w-md mx-auto mb-6 text-center space-y-2">
        <div className="inline-flex items-center justify-center p-3 rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/30 mb-2">
          <FileText className="h-7 w-7" />
        </div>
        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-slate-900 dark:text-white">
          CloudNote Studio
        </h1>
        <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 max-w-sm mx-auto">
          আপনার সমস্ত নোট ক্লাউড ডাটাবেজে স্বয়ংক্রিয়ভাবে সংরক্ষিত ও সিঙ্ক থাকবে।
        </p>
      </div>

      {/* Main Authentication Card */}
      <div className="w-full max-w-md rounded-3xl bg-white dark:bg-slate-900 p-6 sm:p-8 shadow-xl border border-slate-200/80 dark:border-slate-800 space-y-5">
        {/* Header Tabs: Login vs Register */}
        <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100 dark:bg-slate-800 rounded-2xl">
          <button
            type="button"
            onClick={() => {
              setMode('login');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'login'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            লগইন (Sign In)
          </button>
          <button
            type="button"
            onClick={() => {
              setMode('register');
              setErrorMsg(null);
              setSuccessMsg(null);
            }}
            className={`py-2.5 text-xs font-bold rounded-xl transition-all cursor-pointer ${
              mode === 'register'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                : 'text-slate-500 hover:text-slate-800 dark:text-slate-400 dark:hover:text-white'
            }`}
          >
            নতুন একাউন্ট (Sign Up)
          </button>
        </div>

        {/* Informational Subtitle */}
        <div className="text-center pb-1">
          <h2 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white">
            {mode === 'login'
              ? 'আপনার অ্যাকাউন্টে লগইন করুন'
              : mode === 'register'
              ? 'নতুন ক্লাউড অ্যাকাউন্ট খুলুন'
              : 'পাসওয়ার্ড রিসেট করুন'}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            {mode === 'login'
              ? 'ইমেইল দিয়ে লগইন করলেই আপনার সমস্ত সেভ করা নোট চলে আসবে।'
              : mode === 'register'
              ? '১ মিনিটে একাউন্ট খুলে যেকোনো ডিভাইস থেকে নোট সিঙ্ক করুন।'
              : 'আপনার নিবন্ধিত ইমেইল লিখুন।'}
          </p>
        </div>

        {/* Error Alert */}
        {errorMsg && (
          <div className="p-3.5 rounded-2xl bg-rose-50 dark:bg-rose-950/60 border border-rose-200 dark:border-rose-900/60 flex items-start gap-2.5 text-xs text-rose-700 dark:text-rose-300">
            <AlertCircle className="h-4 w-4 shrink-0 mt-0.5 text-rose-600" />
            <span className="leading-relaxed">{errorMsg}</span>
          </div>
        )}

        {/* Success Alert */}
        {successMsg && (
          <div className="p-3.5 rounded-2xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-900/60 flex items-start gap-2.5 text-xs text-emerald-700 dark:text-emerald-300">
            <CheckCircle2 className="h-4 w-4 shrink-0 mt-0.5 text-emerald-600" />
            <span className="leading-relaxed">{successMsg}</span>
          </div>
        )}

        {/* Form Inputs */}
        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === 'register' && (
            <div className="relative">
              <UserIcon className="h-4 w-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="আপনার নাম (ঐচ্ছিক)"
                className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
            </div>
          )}

          <div className="relative">
            <Mail className="h-4 w-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="আপনার ইমেইল (যেমন: your@email.com)"
              className="w-full pl-11 pr-4 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
            />
          </div>

          {mode !== 'forgot' && (
            <div className="relative">
              <Lock className="h-4 w-4 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type={showPassword ? 'text' : 'password'}
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="পাসওয়ার্ড (কমপক্ষে ৬ অক্ষর)"
                className="w-full pl-11 pr-11 py-3 rounded-2xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600"
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
                title={showPassword ? 'পাসওয়ার্ড লুকান' : 'পাসওয়ার্ড দেখুন'}
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          )}

          {/* Forgot Password Link */}
          {mode === 'login' && (
            <div className="text-right">
              <button
                type="button"
                onClick={() => {
                  setMode('forgot');
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="text-xs text-indigo-600 dark:text-indigo-400 hover:underline cursor-pointer"
              >
                পাসওয়ার্ড ভুলে গেছেন?
              </button>
            </div>
          )}

          {mode === 'forgot' && (
            <div className="text-left">
              <button
                type="button"
                onClick={() => {
                  setMode('login');
                  setErrorMsg(null);
                  setSuccessMsg(null);
                }}
                className="text-xs text-slate-500 hover:underline cursor-pointer"
              >
                ← লগইনে ফিরে যান
              </button>
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 px-5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-md shadow-indigo-600/20 active:scale-95 disabled:opacity-60"
          >
            <span>
              {loading
                ? 'অনলাইন ক্লাউডে কানেক্ট হচ্ছে...'
                : mode === 'login'
                ? 'লগইন করে নোট খুলুন'
                : mode === 'register'
                ? 'নতুন একাউন্ট তৈরি করুন'
                : 'রিসেট লিংক পাঠান'}
            </span>
            <ArrowRight className="h-4 w-4" />
          </button>
        </form>

        {/* Feature Badges */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-3 gap-2 text-center text-[10px] text-slate-500 dark:text-slate-400">
          <div className="flex flex-col items-center gap-1">
            <Cloud className="h-3.5 w-3.5 text-indigo-500" />
            <span>ক্লাউড ব্যাকআপ</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <BookOpen className="h-3.5 w-3.5 text-emerald-500" />
            <span>রিডিং ও এডিট মোড</span>
          </div>
          <div className="flex flex-col items-center gap-1">
            <ShieldCheck className="h-3.5 w-3.5 text-purple-500" />
            <span>নিরাপদ ডেটা</span>
          </div>
        </div>
      </div>
    </div>
  );
};
