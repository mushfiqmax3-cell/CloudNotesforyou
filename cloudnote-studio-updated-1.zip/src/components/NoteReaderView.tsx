import React, { useState } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkBreaks from 'remark-breaks';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  Edit3,
  BookOpen,
  Copy,
  Check,
  Printer,
  Download,
  Star,
  Pin,
  Layers,
  Clock,
  FileText,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Folder,
  Tag,
  Share2,
  Sparkles,
} from 'lucide-react';
import {
  NoteItem,
  FolderItem,
  getNormalizedSections,
  FontFamilyOption,
} from '../lib/types';
import { exportNoteToPrint } from '../lib/pdf-export';

interface NoteReaderViewProps {
  note: NoteItem;
  folders: FolderItem[];
  fontFamily: FontFamilyOption;
  onEnterEditMode: () => void;
  onToggleFavorite: (note: NoteItem) => void;
  onOpenFullScreenReading: () => void;
}

export const NoteReaderView: React.FC<NoteReaderViewProps> = ({
  note,
  folders,
  fontFamily,
  onEnterEditMode,
  onToggleFavorite,
  onOpenFullScreenReading,
}) => {
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(2); // 1 to 4
  const [copiedFullNote, setCopiedFullNote] = useState(false);
  const [copiedSectionId, setCopiedSectionId] = useState<string | null>(null);
  const [copiedCodeSnippet, setCopiedCodeSnippet] = useState<string | null>(null);

  const sections = getNormalizedSections(note);
  const folderName =
    folders.find((f) => f.id === note.folderId)?.name.split(' (')[0] || 'সাধারণ';

  // Stats
  const totalWords = sections.reduce((acc, s) => {
    const w = s.content.trim() ? s.content.trim().split(/\s+/).length : 0;
    return acc + w;
  }, 0);
  const readTimeMin = Math.max(1, Math.ceil(totalWords / 180));

  // Font styling
  const fontClasses = {
    sans: 'font-sans',
    serif: 'font-serif',
    mono: 'font-mono',
    'noto-sans-bengali': 'font-noto-sans-bengali',
    'solaiman-lipi': 'font-solaiman-lipi',
    kalpurush: 'font-kalpurush',
    'hind-siliguri': 'font-hind-siliguri',
    'noto-serif-bengali': 'font-noto-serif-bengali',
    'tiro-bangla': 'font-tiro-bangla',
    georgia: 'font-georgia',
    'times-new-roman': 'font-times-new-roman',
  }[fontFamily];

  const fontSizeClasses = [
    'text-xs sm:text-sm leading-relaxed',
    'text-sm sm:text-base leading-relaxed',
    'text-base sm:text-lg leading-loose',
    'text-lg sm:text-xl leading-loose',
  ][fontSizeLevel - 1] || 'text-sm sm:text-base leading-relaxed';

  // Copy full note with section headers
  const handleCopyFullNoteWithTitles = async () => {
    const combinedWithTitles = sections
      .map((s, idx) => `[${s.title || `অধ্যায় ${idx + 1}`}]\n${s.content}`)
      .join('\n\n---\n\n');

    try {
      await navigator.clipboard.writeText(combinedWithTitles);
      setCopiedFullNote(true);
      setTimeout(() => setCopiedFullNote(false), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = combinedWithTitles;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedFullNote(true);
      setTimeout(() => setCopiedFullNote(false), 2000);
    }
  };

  // Copy single section content only (without title)
  const handleCopySectionContentOnly = async (secId: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedSectionId(secId);
      setTimeout(() => setCopiedSectionId(null), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = content;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedSectionId(secId);
      setTimeout(() => setCopiedSectionId(null), 2000);
    }
  };

  return (
    <div className={`space-y-4 ${fontClasses}`}>
      {/* Top Reading Navigation & Action Header */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm p-4 sm:p-5">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3.5">
          {/* Left: Reading Mode Tag + Info */}
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-600 dark:text-indigo-400">
              <BookOpen className="h-5 w-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2 py-0.5 rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 text-[11px] font-bold">
                  রিডিং মোড (Reading Mode)
                </span>
                <span className="text-xs text-slate-400">•</span>
                <span className="text-xs text-slate-500 dark:text-slate-400 font-medium">
                  পড়ার জন্য প্রস্তুত
                </span>
              </div>
              <p className="text-[11px] text-slate-400 mt-0.5">
                নোট পরিবর্তন করতে ডানপাশের &quot;এডিট করুন&quot; বাটনে ক্লিক করুন।
              </p>
            </div>
          </div>

          {/* Right Action Tools: EDIT BUTTON (Prominent), Font Controls, Copy, Print */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Primary EDIT Button - User requirement: "then user edit a click korle tokhon Edit mode a Jabe" */}
            <button
              type="button"
              onClick={onEnterEditMode}
              className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold shadow-md shadow-indigo-600/20 transition-all active:scale-95 cursor-pointer"
              title="এই নোটটি এডিট করতে ক্লিক করুন"
            >
              <Edit3 className="h-4 w-4" />
              <span>নোট এডিট করুন (Edit)</span>
            </button>

            {/* Font Size Adjuster */}
            <div className="flex items-center rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/80 p-0.5">
              <button
                type="button"
                disabled={fontSizeLevel <= 1}
                onClick={() => setFontSizeLevel((l) => Math.max(1, l - 1))}
                className="p-1.5 rounded-xl opacity-75 hover:opacity-100 disabled:opacity-30 cursor-pointer"
                title="লেখা ছোট করুন"
              >
                <ZoomOut className="h-3.5 w-3.5" />
              </button>
              <span className="px-2 text-xs font-mono font-bold text-slate-700 dark:text-slate-300">
                A{fontSizeLevel}
              </span>
              <button
                type="button"
                disabled={fontSizeLevel >= 4}
                onClick={() => setFontSizeLevel((l) => Math.min(4, l + 1))}
                className="p-1.5 rounded-xl opacity-75 hover:opacity-100 disabled:opacity-30 cursor-pointer"
                title="লেখা বড় করুন"
              >
                <ZoomIn className="h-3.5 w-3.5" />
              </button>
            </div>

            {/* Copy Full Note with Titles */}
            <button
              type="button"
              onClick={handleCopyFullNoteWithTitles}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-2xl text-xs font-bold transition-all active:scale-95 cursor-pointer ${
                copiedFullNote
                  ? 'bg-emerald-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-slate-200'
              }`}
              title="অধ্যায়ের নামসহ পুরো নোট একসাথে কপি করুন"
            >
              {copiedFullNote ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
              <span className="hidden sm:inline">
                {copiedFullNote ? 'কপিড!' : 'সব কপি'}
              </span>
            </button>

            {/* Favorite toggle */}
            <button
              type="button"
              onClick={() => onToggleFavorite(note)}
              className={`p-2 rounded-2xl transition-colors cursor-pointer ${
                note.isFavorite
                  ? 'bg-rose-50 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600'
              }`}
              title={note.isFavorite ? 'ফেভারিট থেকে সরান' : 'ফেভারিট করুন'}
            >
              <Star className={`h-4 w-4 ${note.isFavorite ? 'fill-rose-500' : ''}`} />
            </button>

            {/* Full-Screen Reading Modal trigger */}
            <button
              type="button"
              onClick={onOpenFullScreenReading}
              className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-indigo-50 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 transition-colors cursor-pointer"
              title="ফুল-স্ক্রিন মোডে পড়ুন"
            >
              <Maximize2 className="h-4 w-4" />
            </button>

            {/* Print / PDF */}
            <button
              type="button"
              onClick={() => exportNoteToPrint(note)}
              className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
              title="প্রিন্ট বা PDF হিসেবে সেভ"
            >
              <Printer className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Reading Card Article */}
      <article className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm p-5 sm:p-8 space-y-6">
        {/* Title & Metadata Header */}
        <div className="pb-6 border-b border-slate-100 dark:border-slate-800/80 space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 text-xs font-semibold">
              <Folder className="h-3 w-3" />
              <span>{folderName}</span>
            </span>
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 text-xs font-semibold">
              <Tag className="h-3 w-3" />
              <span>{note.category}</span>
            </span>
            {note.isPinned && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 text-xs font-semibold">
                <Pin className="h-3 w-3 fill-amber-500" />
                <span>পিন করা</span>
              </span>
            )}
          </div>

          <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight leading-snug">
            {note.title || 'শিরোনামহীন নোট'}
          </h1>

          <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 pt-1">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              <span>{new Date(note.updatedAt).toLocaleDateString('bn-BD', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
              })}</span>
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Layers className="h-3.5 w-3.5" />
              <span>{sections.length} অধ্যায় / অংশ</span>
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <FileText className="h-3.5 w-3.5" />
              <span>{totalWords} শব্দ</span>
            </span>
            <span>•</span>
            <span>~{readTimeMin} মিনিট পাঠ</span>
          </div>
        </div>

        {/* Sections / Content List */}
        <div className="space-y-8">
          {sections.map((sec, idx) => (
            <div
              key={sec.id}
              className="space-y-3.5 p-4 sm:p-6 rounded-2xl bg-slate-50/60 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800/80 hover:border-indigo-200 dark:hover:border-indigo-900/40 transition-colors"
            >
              {/* Section Header */}
              <div className="flex items-center justify-between pb-3 border-b border-slate-200/60 dark:border-slate-700/60">
                <div className="flex items-center gap-2">
                  <span className="w-6 h-6 rounded-lg bg-indigo-600 text-white text-xs font-bold flex items-center justify-center">
                    {idx + 1}
                  </span>
                  <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                    {sec.title || `অধ্যায় ${idx + 1}`}
                  </h3>
                </div>

                {/* Single Section Copy Button (copies content only, without title) */}
                <button
                  type="button"
                  onClick={() => handleCopySectionContentOnly(sec.id, sec.content)}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-xl text-[11px] font-bold transition-all active:scale-95 cursor-pointer ${
                    copiedSectionId === sec.id
                      ? 'bg-emerald-600 text-white'
                      : 'bg-white dark:bg-slate-800 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700'
                  }`}
                  title="শুধুমাত্র এই অংশের ভেতরের লেখা কপি করুন"
                >
                  {copiedSectionId === sec.id ? (
                    <>
                      <Check className="h-3 w-3 text-white" />
                      <span>কপিড!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3 w-3" />
                      <span>অংশ কপি</span>
                    </>
                  )}
                </button>
              </div>

              {/* Section Body with Rich Markdown & LaTeX */}
              <div
                className={`prose prose-slate dark:prose-invert max-w-none ${fontSizeClasses} break-words whitespace-pre-wrap`}
              >
                <Markdown
                  remarkPlugins={[remarkGfm, remarkBreaks, remarkMath]}
                  rehypePlugins={[rehypeKatex]}
                  components={{
                    p: ({ children }) => <div className="mb-0 leading-relaxed whitespace-pre-wrap">{children}</div>,
                    code({ className, children, ...props }) {
                      const match = /language-(\w+)/.exec(className || '');
                      const codeString = String(children).replace(/\n$/, '');
                      const isInline = !match && !String(children).includes('\n');

                      if (isInline) {
                        return (
                          <code
                            className="px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-mono text-[0.88em] border border-indigo-200/50 dark:border-indigo-800/50"
                            {...props}
                          >
                            {children}
                          </code>
                        );
                      }

                      return (
                        <div className="relative group my-4 rounded-2xl overflow-hidden border border-slate-200/80 dark:border-slate-700/80 bg-slate-950 text-slate-100">
                          <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900/90 border-b border-slate-800 text-[11px] text-slate-400 font-mono">
                            <span>{match ? match[1] : 'code'}</span>
                            <button
                              type="button"
                              onClick={async () => {
                                await navigator.clipboard.writeText(codeString);
                                setCopiedCodeSnippet(codeString);
                                setTimeout(() => setCopiedCodeSnippet(null), 1800);
                              }}
                              className="flex items-center gap-1 hover:text-white transition-colors cursor-pointer"
                            >
                              {copiedCodeSnippet === codeString ? (
                                <>
                                  <Check className="h-3 w-3 text-emerald-400" />
                                  <span>কপি হয়েছে!</span>
                                </>
                              ) : (
                                <>
                                  <Copy className="h-3 w-3" />
                                  <span>কোড কপি</span>
                                </>
                              )}
                            </button>
                          </div>
                          <pre className="p-3.5 overflow-x-auto text-xs font-mono leading-relaxed bg-transparent text-slate-200">
                            <code>{children}</code>
                          </pre>
                        </div>
                      );
                    },
                    table({ children }) {
                      return (
                        <div className="my-4 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700">
                          <table className="w-full text-left text-xs border-collapse">
                            {children}
                          </table>
                        </div>
                      );
                    },
                    th({ children }) {
                      return (
                        <th className="px-3 py-2 bg-slate-100 dark:bg-slate-800 font-bold border-b border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200">
                          {children}
                        </th>
                      );
                    },
                    td({ children }) {
                      return (
                        <td className="px-3 py-2 border-b border-slate-100 dark:border-slate-800 text-slate-700 dark:text-slate-300">
                          {children}
                        </td>
                      );
                    },
                  }}
                >
                  {sec.content || '(এই অংশে এখনো কোনো লেখা নেই)'}
                </Markdown>
              </div>
            </div>
          ))}
        </div>

        {/* Bottom Prominent Edit Callout */}
        <div className="pt-6 border-t border-slate-100 dark:border-slate-800/80 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <p className="text-xs text-slate-500 dark:text-slate-400">
            পড়া শেষ? লেখায় পরিবর্তন আনতে বা নতুন অধ্যায় যোগ করতে নিচের বাটনে চাপ দিন।
          </p>
          <button
            type="button"
            onClick={onEnterEditMode}
            className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs sm:text-sm font-bold shadow-md shadow-indigo-600/20 transition-all active:scale-95 cursor-pointer"
          >
            <Edit3 className="h-4 w-4" />
            <span>এখনই এডিট করুন (Edit Note)</span>
          </button>
        </div>
      </article>
    </div>
  );
};
