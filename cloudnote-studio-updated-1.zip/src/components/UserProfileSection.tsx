import React, { useEffect, useState } from 'react';
import { User, Mail, Phone, LogOut, Save, Pencil } from 'lucide-react';
import { UserProfile } from '../lib/types';

interface UserProfileSectionProps {
  user: UserProfile;
  notes?: never;
  folders?: never;
  onSignOut: () => void;
  onSaveProfile: (name: string, email: string, phone: string) => Promise<void>;
}

export const UserProfileSection: React.FC<UserProfileSectionProps> = ({ user, onSignOut, onSaveProfile }) => {
  const [editing, setEditing] = useState(false);
  const [name, setName] = useState(user.displayName || '');
  const [email, setEmail] = useState(user.email || '');
  const [phone, setPhone] = useState(user.phoneNumber || '');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setName(user.displayName || '');
    setEmail(user.email || '');
    setPhone(user.phoneNumber || '');
  }, [user.uid, user.displayName, user.email, user.phoneNumber]);

  const handleSave = async () => {
    if (!name.trim() || !email.trim()) return;
    setSaving(true);
    try {
      await onSaveProfile(name, email, phone);
      setEditing(false);
    } finally {
      setSaving(false);
    }
  };

  return (
    <section className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 p-5 sm:p-7 shadow-sm space-y-5">
      <div className="flex items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
        <div>
          <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">প্রোফাইল</h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">নাম, ইমেইল ও ফোন নম্বর</p>
        </div>
        <button type="button" onClick={() => setEditing((v) => !v)} className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-100 dark:bg-slate-800 text-xs font-bold text-slate-700 dark:text-slate-200">
          <Pencil className="h-3.5 w-3.5" /> {editing ? 'বাতিল' : 'Edit'}
        </button>
      </div>

      <div className="space-y-3">
        <label className="block">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-300">নাম</span>
          <div className="mt-1.5 flex items-center gap-2 px-3.5 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <User className="h-4 w-4 text-slate-400" />
            <input disabled={!editing} value={name} onChange={(e) => setName(e.target.value)} className="w-full bg-transparent outline-none text-sm text-slate-800 dark:text-slate-100 disabled:opacity-80" />
          </div>
        </label>
        <label className="block">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-300">ইমেইল</span>
          <div className="mt-1.5 flex items-center gap-2 px-3.5 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <Mail className="h-4 w-4 text-slate-400" />
            <input disabled={!editing} type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full bg-transparent outline-none text-sm text-slate-800 dark:text-slate-100 disabled:opacity-80" />
          </div>
        </label>
        <label className="block">
          <span className="text-xs font-bold text-slate-600 dark:text-slate-300">ফোন নম্বর</span>
          <div className="mt-1.5 flex items-center gap-2 px-3.5 py-3 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700">
            <Phone className="h-4 w-4 text-slate-400" />
            <input disabled={!editing} type="tel" value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="ফোন নম্বর দিন" className="w-full bg-transparent outline-none text-sm text-slate-800 dark:text-slate-100 disabled:opacity-80" />
          </div>
        </label>
      </div>

      {editing && (
        <button type="button" disabled={saving} onClick={handleSave} className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white text-sm font-bold">
          <Save className="h-4 w-4" /> {saving ? 'সেভ হচ্ছে…' : 'পরিবর্তন সেভ করুন'}
        </button>
      )}

      <div className="pt-4 border-t border-slate-100 dark:border-slate-800">
        <button type="button" onClick={onSignOut} className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-xl bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 text-sm font-bold border border-rose-200 dark:border-rose-900">
          <LogOut className="h-4 w-4" /> লগআউট করুন
        </button>
      </div>
    </section>
  );
};
