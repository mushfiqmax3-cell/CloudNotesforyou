import React, { useState, useEffect } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkBreaks from 'remark-breaks';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  X,
  Copy,
  Check,
  Printer,
  Moon,
  Sun,
  BookOpen,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Clock,
  FileText,
  Layers,
} from 'lucide-react';
import { NoteItem, getNormalizedSections } from '../lib/types';
import { exportNoteToPrint } from '../lib/pdf-export';

interface ReadingModeModalProps {
  note: NoteItem;
  isOpen: boolean;
  onClose: () => void;
}

export function ReadingModeModal({ note, isOpen, onClose }: ReadingModeModalProps) {
  const [readingTheme, setReadingTheme] = useState<'dark' | 'light' | 'sepia'>('dark');
  const [fontSizeLevel, setFontSizeLevel] = useState<number>(2); // 1 to 4
  const [contentWidth, setContentWidth] = useState<'normal' | 'wide' | 'narrow'>('normal');
  const [copiedFull, setCopiedFull] = useState(false);
  const [copiedSecId, setCopiedSecId] = useState<string | null>(null);

  const sections = getNormalizedSections(note);

  // Close on Escape key
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'hidden';
    }
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      document.body.style.overflow = 'auto';
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  // Requirement: Copy full note WITH section/chapter titles
  const handleCopyFullNoteWithTitles = async () => {
    const combinedWithTitles = sections
      .map((s, idx) => `[${s.title || `অধ্যায় ${idx + 1}`}]\n${s.content}`)
      .join('\n\n---\n\n');

    try {
      await navigator.clipboard.writeText(combinedWithTitles);
      setCopiedFull(true);
      setTimeout(() => setCopiedFull(false), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = combinedWithTitles;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedFull(true);
      setTimeout(() => setCopiedFull(false), 2000);
    }
  };

  // Requirement: Copy single section content ONLY (no chapter/section title)
  const handleCopySectionContentOnly = async (secId: string, content: string) => {
    try {
      await navigator.clipboard.writeText(content);
      setCopiedSecId(secId);
      setTimeout(() => setCopiedSecId(null), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = content;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedSecId(secId);
      setTimeout(() => setCopiedSecId(null), 2000);
    }
  };

  const totalWords = sections.reduce((acc, s) => {
    const w = s.content.trim() ? s.content.trim().split(/\s+/).length : 0;
    return acc + w;
  }, 0);
  const readTimeMin = Math.max(1, Math.ceil(totalWords / 180));

  // Themes
  const themeClasses = {
    dark: 'bg-[#090D16] text-slate-100 selection:bg-indigo-600 selection:text-white',
    light: 'bg-[#FAFAF9] text-slate-900 selection:bg-indigo-600 selection:text-white',
    sepia: 'bg-[#FBF0D9] text-[#423321] selection:bg-amber-600 selection:text-white',
  }[readingTheme];

  const headerBorder = {
    dark: 'border-slate-800/80 bg-[#090D16]/90',
    light: 'border-slate-200/80 bg-[#FAFAF9]/90',
    sepia: 'border-[#ebd6b2] bg-[#FBF0D9]/90',
  }[readingTheme];

  const cardBorder = {
    dark: 'bg-slate-900/50 border-slate-800 text-slate-200',
    light: 'bg-white border-slate-200/80 text-slate-800 shadow-xs',
    sepia: 'bg-[#f4e4c3] border-[#e2ceaa] text-[#423321]',
  }[readingTheme];

  const fontSizeClasses = [
    'text-sm leading-relaxed',
    'text-base leading-relaxed',
    'text-lg leading-loose',
    'text-xl leading-loose',
  ][fontSizeLevel - 1] || 'text-lg leading-loose';

  const widthClasses = {
    narrow: 'max-w-2xl',
    normal: 'max-w-3xl',
    wide: 'max-w-5xl',
  }[contentWidth];

  return (
    <div className={`fixed inset-0 z-50 flex flex-col overflow-hidden ${themeClasses}`}>
      {/* Top Floating Controls Bar */}
      <header className={`sticky top-0 z-20 px-4 sm:px-8 py-3 border-b backdrop-blur-md flex items-center justify-between gap-3 ${headerBorder}`}>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 text-indigo-500 font-bold text-sm">
            <BookOpen className="h-4 w-4" />
            <span className="hidden sm:inline">রিডিং মোড (Reading Mode)</span>
          </div>

          <div className="hidden md:flex items-center gap-2 text-xs opacity-75 tabular-nums">
            <span>•</span>
            <span className="flex items-center gap-1">
              <Layers className="h-3 w-3" /> {sections.length} অধ্যায়
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <FileText className="h-3 w-3" /> {totalWords} শব্দ
            </span>
            <span>•</span>
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" /> ~{readTimeMin} মিনিট পাঠ
            </span>
          </div>
        </div>

        {/* Customization Toolset */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Themes: Dark, Light, Sepia */}
          <div className="flex items-center p-0.5 rounded-xl border border-current/20 text-xs">
            <button
              type="button"
              onClick={() => setReadingTheme('dark')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                readingTheme === 'dark' ? 'bg-indigo-600 text-white' : 'opacity-70 hover:opacity-100'
              }`}
              title="ডার্ক মোড"
            >
              <Moon className="h-3.5 w-3.5 inline mr-1" />
              <span className="hidden sm:inline">ডার্ক</span>
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('light')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                readingTheme === 'light' ? 'bg-indigo-600 text-white' : 'opacity-70 hover:opacity-100'
              }`}
              title="লাইট মোড"
            >
              <Sun className="h-3.5 w-3.5 inline mr-1" />
              <span className="hidden sm:inline">লাইট</span>
            </button>
            <button
              type="button"
              onClick={() => setReadingTheme('sepia')}
              className={`px-2 py-1 rounded-lg font-medium transition-colors ${
                readingTheme === 'sepia' ? 'bg-amber-700 text-white' : 'opacity-70 hover:opacity-100'
              }`}
              title="সেপিয়া মোড"
            >
              <span className="hidden sm:inline">সেপিয়া</span>
              <span className="sm:hidden">S</span>
            </button>
          </div>

          {/* Font Size Adjuster */}
          <div className="flex items-center rounded-xl border border-current/20 p-0.5">
            <button
              type="button"
              disabled={fontSizeLevel <= 1}
              onClick={() => setFontSizeLevel((l) => Math.max(1, l - 1))}
              className="p-1 rounded-lg opacity-70 hover:opacity-100 disabled:opacity-30 cursor-pointer"
              title="লেখা ছোট করুন"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </button>
            <span className="px-1 text-[11px] font-mono font-bold">{fontSizeLevel}</span>
            <button
              type="button"
              disabled={fontSizeLevel >= 4}
              onClick={() => setFontSizeLevel((l) => Math.min(4, l + 1))}
              className="p-1 rounded-lg opacity-70 hover:opacity-100 disabled:opacity-30 cursor-pointer"
              title="লেখা বড় করুন"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </button>
          </div>

          {/* Width toggles */}
          <button
            type="button"
            onClick={() => {
              if (contentWidth === 'narrow') setContentWidth('normal');
              else if (contentWidth === 'normal') setContentWidth('wide');
              else setContentWidth('narrow');
            }}
            className="p-2 rounded-xl border border-current/20 opacity-70 hover:opacity-100 transition-colors cursor-pointer hidden sm:block"
            title="স্ক্রিনের প্রস্থ পরিবর্তন করুন"
          >
            <Maximize2 className="h-3.5 w-3.5" />
          </button>

          {/* Copy Full Note with Titles */}
          <button
            type="button"
            onClick={handleCopyFullNoteWithTitles}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-current/25 hover:bg-indigo-600 hover:text-white transition-all text-xs font-bold cursor-pointer"
            title="অধ্যায়সহ পুরো নোট কপি করুন"
          >
            {copiedFull ? (
              <>
                <Check className="h-3.5 w-3.5 text-emerald-400" />
                <span>কপিড!</span>
              </>
            ) : (
              <>
                <Copy className="h-3.5 w-3.5" />
                <span className="hidden sm:inline">সব কপি</span>
              </>
            )}
          </button>

          {/* Print */}
          <button
            type="button"
            onClick={() => exportNoteToPrint(note)}
            className="p-2 rounded-xl border border-current/20 opacity-70 hover:opacity-100 transition-colors cursor-pointer"
            title="প্রিন্ট করুন"
          >
            <Printer className="h-3.5 w-3.5" />
          </button>

          {/* Close */}
          <button
            type="button"
            onClick={onClose}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-rose-600/90 hover:bg-rose-600 text-white text-xs font-bold shadow-xs transition-colors cursor-pointer"
            title="পড়া শেষ করুন (Esc)"
          >
            <X className="h-4 w-4" />
            <span className="hidden sm:inline">পড়া শেষ</span>
          </button>
        </div>
      </header>

      {/* Main Full-Screen Reading Flow */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-8 py-8 sm:py-12">
        <article className={`mx-auto ${widthClasses} space-y-8`}>
          {/* Note Title & Meta */}
          <div className="pb-6 border-b border-current/15 space-y-2.5">
            <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">
              {note.title || 'শিরোনামহীন নোট'}
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-xs opacity-70">
              <span className="px-2.5 py-1 rounded-lg bg-indigo-500/10 text-indigo-400 font-semibold">
                {note.category}
              </span>
              <span>•</span>
              <span className="tabular-nums">
                {new Date(note.updatedAt).toLocaleDateString('bn-BD', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </span>
              <span>•</span>
              <span>{sections.length} টি অধ্যায়</span>
              <span>•</span>
              <span>{totalWords} শব্দ</span>
              <span>•</span>
              <span>~{readTimeMin} মিনিট পাঠ</span>
            </div>
          </div>

          {/* Render each section separately with clean section copy button */}
          <div className="space-y-8">
            {sections.map((sec, idx) => {
              const isSecCopied = copiedSecId === sec.id;

              return (
                <div key={sec.id} className={`rounded-2xl p-5 sm:p-7 border ${cardBorder} space-y-4`}>
                  <div className="flex items-center justify-between gap-3 pb-3 border-b border-current/10">
                    <div className="flex items-center gap-2">
                      <span className="inline-flex items-center justify-center h-6 w-6 rounded-lg bg-indigo-500/15 text-indigo-400 text-xs font-bold tabular-nums">
                        {idx + 1}
                      </span>
                      <h2 className="text-base sm:text-lg font-bold">
                        {sec.title || `অধ্যায় ${idx + 1}`}
                      </h2>
                    </div>

                    {/* Requirement:
                        "প্রতিটা অংশ আলাদা আলাদা ভাবে কপি করার ক্ষেত্রে অধ্যায়ের নাম সহ কপি করা দরকার নাই শুধুমাত্র কনটেন্ট কপি করলেই হবে।"
                    */}
                    <button
                      type="button"
                      onClick={() => handleCopySectionContentOnly(sec.id, sec.content)}
                      className="flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border border-current/20 hover:bg-indigo-600 hover:text-white transition-colors cursor-pointer"
                      title="নাম ছাড়া শুধু এই অংশের লেখা কপি করুন"
                    >
                      {isSecCopied ? (
                        <>
                          <Check className="h-3 w-3 text-emerald-400" />
                          <span>কপিড!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          <span>লেখা কপি</span>
                        </>
                      )}
                    </button>
                  </div>

                  {/* Rendered content */}
                  <div className={`markdown-content ${fontSizeClasses}`}>
                    <Markdown
                      remarkPlugins={[remarkGfm, remarkBreaks, remarkMath]}
                      rehypePlugins={[rehypeKatex]}
                      components={{
                        code(props) {
                          const { children, className, ...rest } = props;
                          const match = /language-(\w+)/.exec(className || '');
                          const codeString = String(children).replace(/\n$/, '');
                          const isBlock = Boolean(match || codeString.includes('\n'));

                          if (isBlock) {
                            const lang = match ? match[1] : 'code';
                            return (
                              <div className="my-4 rounded-xl overflow-hidden bg-slate-950 text-slate-100 border border-slate-800">
                                <div className="flex items-center justify-between px-3.5 py-1.5 bg-slate-900 border-b border-slate-800 text-xs font-mono">
                                  <span className="text-indigo-400 uppercase font-semibold">{lang}</span>
                                  <button
                                    type="button"
                                    onClick={async () => {
                                      await navigator.clipboard.writeText(codeString);
                                    }}
                                    className="px-2 py-0.5 rounded bg-white/10 hover:bg-white/20 text-white text-[11px] font-sans"
                                  >
                                    কোড কপি
                                  </button>
                                </div>
                                <pre className="p-3.5 overflow-x-auto text-xs sm:text-sm font-mono leading-relaxed m-0">
                                  <code className={className} {...rest}>
                                    {children}
                                  </code>
                                </pre>
                              </div>
                            );
                          }
                          return (
                            <code className="px-1.5 py-0.5 rounded bg-current/10 font-mono text-[0.9em]" {...rest}>
                              {children}
                            </code>
                          );
                        },
                        table({ children }) {
                          return (
                            <div className="my-4 overflow-x-auto rounded-xl border border-current/20">
                              <table>{children}</table>
                            </div>
                          );
                        },
                      }}
                    >
                      {sec.content || '*এই অধ্যায়ে কোনো লেখা নেই...*'}
                    </Markdown>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Reading Completion Footer */}
          <div className="pt-8 text-center">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-2.5 rounded-2xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold transition-all cursor-pointer shadow-md"
            >
              পড়া শেষ করুন (সাধারণ মোডে ফিরুন)
            </button>
          </div>
        </article>
      </div>
    </div>
  );
}
