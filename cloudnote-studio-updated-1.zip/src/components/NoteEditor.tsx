import React, { useState, useRef, useEffect } from 'react';
import Markdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import remarkBreaks from 'remark-breaks';
import remarkMath from 'remark-math';
import rehypeKatex from 'rehype-katex';
import {
  Copy,
  Check,
  Save,
  BookOpen,
  Eye,
  Edit3,
  Bold,
  Italic,
  Heading2,
  List,
  Code2,
  Table as TableIcon,
  Trash2,
  Folder,
  Tag,
  Download,
  Pin,
  Star,
  Sparkles,
  Sigma,
  Plus,
  Layers,
  Mic,
  MicOff,
} from 'lucide-react';
import {
  NoteItem,
  NoteSection,
  FolderItem,
  DEFAULT_CATEGORIES,
  FontFamilyOption,
  getNormalizedSections,
  combineSectionsToContent,
} from '../lib/types';
import { exportNoteToPrint } from '../lib/pdf-export';
import { ReadingModeModal } from './ReadingModeModal';

interface NoteEditorProps {
  note: NoteItem;
  folders: FolderItem[];
  isNewDraft?: boolean;
  onSave: (savedNote: NoteItem) => void;
  onCancelDraft?: () => void;
  onDelete?: (id: string) => void;
  onSwitchToReadingMode?: () => void;
  fontFamily: FontFamilyOption;
  isSaving: boolean;
  lastSavedText: string;
}

const UNICODE_MATH_SYMBOLS = [
  '√', '∑', '∫', '∞', 'π', 'Δ', 'θ', 'λ', '≈', '≠', '≤', '≥', '±', '×', '÷', '∈', '∀', '∃', '∂', '∇', '→',
];

export function NoteEditor({
  note,
  folders,
  isNewDraft = false,
  onSave,
  onCancelDraft,
  onDelete,
  onSwitchToReadingMode,
  fontFamily,
  isSaving,
  lastSavedText,
}: NoteEditorProps) {
  // Title & metadata
  const [title, setTitle] = useState(note.title);
  const [category, setCategory] = useState(note.category);
  const [folderId, setFolderId] = useState(note.folderId);
  const [isPinned, setIsPinned] = useState(note.isPinned);
  const [isFavorite, setIsFavorite] = useState(note.isFavorite);

  // Multiple sections within this note
  const [sections, setSections] = useState<NoteSection[]>(() => getNormalizedSections(note));
  const [activeSectionId, setActiveSectionId] = useState<string>(() => sections[0]?.id || 'sec_1');

  // Preview state per section: id -> boolean
  const [sectionPreviewMap, setSectionPreviewMap] = useState<Record<string, boolean>>({});

  // Global modals & tools
  const [readingModalOpen, setReadingModalOpen] = useState(false);
  const [showSymbols, setShowSymbols] = useState(false);
  const [copiedSingleSecId, setCopiedSingleSecId] = useState<string | null>(null);
  const [copiedFullNote, setCopiedFullNote] = useState(false);
  const [savedFeedback, setSavedFeedback] = useState(false);
  const [copiedCodeSnippet, setCopiedCodeSnippet] = useState<string | null>(null);

  // Voice Typing
  const [isListening, setIsListening] = useState(false);
  const [voiceLang, setVoiceLang] = useState<'bn-BD' | 'en-US'>('bn-BD');
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const recognitionRef = useRef<any>(null);

  const textareaRefs = useRef<Record<string, HTMLTextAreaElement | null>>({});

  // Keep state synced when switching notes
  useEffect(() => {
    setTitle(note.title);
    setCategory(note.category);
    setFolderId(note.folderId);
    setIsPinned(note.isPinned);
    setIsFavorite(note.isFavorite);
    const normalized = getNormalizedSections(note);
    setSections(normalized);
    setActiveSectionId(normalized[0]?.id || 'sec_1');
    setSectionPreviewMap({});
  }, [note.id]);

  // Voice Typing cleanup
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch {
          // ignore
        }
      }
    };
  }, []);

  // Section Management: Add a new section
  const handleAddSection = () => {
    const nextNum = sections.length + 1;
    const newSec: NoteSection = {
      id: 'sec_' + Date.now() + '_' + Math.random().toString(36).slice(2, 6),
      title: `${nextNum}ম অধ্যায় / অংশ`,
      content: '',
    };
    const updated = [...sections, newSec];
    setSections(updated);
    setActiveSectionId(newSec.id);
    setTimeout(() => {
      textareaRefs.current[newSec.id]?.focus();
    }, 60);
  };

  // Update specific section
  const handleUpdateSection = (id: string, field: 'title' | 'content', value: string) => {
    setSections((prev) =>
      prev.map((sec) => (sec.id === id ? { ...sec, [field]: value } : sec))
    );
  };

  // Delete section
  const handleDeleteSection = (id: string) => {
    if (sections.length <= 1) {
      // Keep at least one section
      setSections([{ id: 'sec_1', title: '১ম অধ্যায় / মূল অংশ', content: '' }]);
      return;
    }
    const updated = sections.filter((s) => s.id !== id);
    setSections(updated);
    if (activeSectionId === id) {
      setActiveSectionId(updated[0]?.id || 'sec_1');
    }
  };

  // Requirement:
  // "প্রতিটা অংশ আলাদা আলাদা ভাবে কপি করার ক্ষেত্রে অধ্যায়ের নাম সহ কপি করা দরকার নাই শুধুমাত্র কনটেন্ট কপি করলেই হবে।"
  const handleCopySingleSectionContentOnly = async (sec: NoteSection) => {
    const textToCopy = sec.content || '';
    try {
      await navigator.clipboard.writeText(textToCopy);
      setCopiedSingleSecId(sec.id);
      setTimeout(() => setCopiedSingleSecId(null), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = textToCopy;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedSingleSecId(sec.id);
      setTimeout(() => setCopiedSingleSecId(null), 2000);
    }
  };

  // Requirement:
  // "তবে পুরো নোটটা একসাথে কপি করার অপশনে ক্লিক করলে অধ্যায়ের নাম সহ একসাথে কপি হবে।"
  const handleCopyFullNoteWithSectionTitles = async () => {
    const combinedWithTitles = sections
      .map((sec, idx) => {
        const secHeader = sec.title ? `[${sec.title}]` : `[অংশ ${idx + 1}]`;
        return `${secHeader}\n${sec.content}`;
      })
      .join('\n\n---\n\n');

    try {
      await navigator.clipboard.writeText(combinedWithTitles);
      setCopiedFullNote(true);
      setTimeout(() => setCopiedFullNote(false), 2200);
    } catch {
      const el = document.createElement('textarea');
      el.value = combinedWithTitles;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedFullNote(true);
      setTimeout(() => setCopiedFullNote(false), 2200);
    }
  };

  // Explicit Save Button
  const handleSaveClick = () => {
    const trimmedTitle = title.trim() || 'শিরোনামহীন নোট';
    const combinedContent = combineSectionsToContent(sections);
    const noteToSave: NoteItem = {
      ...note,
      title: trimmedTitle,
      content: combinedContent,
      sections,
      category,
      folderId,
      isPinned,
      isFavorite,
      updatedAt: Date.now(),
    };
    onSave(noteToSave);
    setSavedFeedback(true);
    setTimeout(() => setSavedFeedback(false), 2500);
  };

  // Insert markdown formatting into active section
  const insertFormatting = (prefix: string, suffix: string = '', sample: string = '') => {
    const currentId = activeSectionId || sections[0]?.id;
    const targetSec = sections.find((s) => s.id === currentId) || sections[0];
    if (!targetSec) return;

    const ta = textareaRefs.current[targetSec.id];
    if (!ta) {
      handleUpdateSection(targetSec.id, 'content', targetSec.content + `\n${prefix}${sample}${suffix}`);
      return;
    }

    const start = ta.selectionStart;
    const end = ta.selectionEnd;
    const curVal = targetSec.content;
    const selected = curVal.substring(start, end) || sample;
    const replacement = `${prefix}${selected}${suffix}`;
    const nextVal = curVal.substring(0, start) + replacement + curVal.substring(end);

    handleUpdateSection(targetSec.id, 'content', nextVal);
    setTimeout(() => {
      ta.focus();
      ta.setSelectionRange(start + prefix.length, start + prefix.length + selected.length);
    }, 25);
  };

  // Voice Typing
  const handleToggleVoiceTyping = () => {
    if (typeof window === 'undefined') return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert('আপনার ব্রাউজারে ভয়েস টাইপিং সাপোর্ট নেই। গুগল ক্রোম ব্যবহার করুন।');
      return;
    }

    if (isListening && recognitionRef.current) {
      recognitionRef.current.stop();
      setIsListening(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = voiceLang;
    recognition.interimResults = false;
    recognition.continuous = false;

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    recognition.onresult = (event: any) => {
      const transcript = event.results?.[0]?.[0]?.transcript || '';
      if (transcript) {
        insertFormatting(transcript + ' ', '', '');
      }
    };
    recognition.onend = () => setIsListening(false);
    recognition.onerror = () => setIsListening(false);

    recognitionRef.current = recognition;
    recognition.start();
    setIsListening(true);
  };

  const fontClasses = {
    sans: 'font-sans',
    serif: 'font-serif',
    mono: 'font-mono',
    'noto-sans-bengali': 'font-noto-sans-bengali',
    'solaiman-lipi': 'font-solaiman-lipi',
    kalpurush: 'font-kalpurush',
    'hind-siliguri': 'font-hind-siliguri',
    'noto-serif-bengali': 'font-noto-serif-bengali',
    'tiro-bangla': 'font-tiro-bangla',
    georgia: 'font-georgia',
    'times-new-roman': 'font-times-new-roman',
  }[fontFamily];

  const totalWords = sections.reduce((acc, s) => {
    const w = s.content.trim() ? s.content.trim().split(/\s+/).length : 0;
    return acc + w;
  }, 0);

  return (
    <div className="rounded-3xl bg-white dark:bg-slate-900 border border-slate-200/80 dark:border-slate-800 shadow-sm overflow-hidden flex flex-col">
      {/* Draft Notification if creating a new note */}
      {isNewDraft && (
        <div className="px-5 py-2.5 bg-amber-500/10 border-b border-amber-500/20 text-amber-700 dark:text-amber-300 text-xs font-semibold flex items-center justify-between">
          <span>
            📝 নতুন নোট তৈরির মোড — নিচের &quot;নোট সেভ করুন (Save)&quot; বাটনে ক্লিক করলেই শুধুমাত্র এটি সেভ হবে।
          </span>
          {onCancelDraft && (
            <button
              type="button"
              onClick={onCancelDraft}
              className="text-xs hover:underline text-amber-800 dark:text-amber-200 cursor-pointer"
            >
              বাতিল করুন
            </button>
          )}
        </div>
      )}

      {/* Editor Control & Meta Bar */}
      <div className="px-4 sm:px-6 py-3.5 border-b border-slate-100 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-900/60 flex flex-wrap items-center justify-between gap-3">
        {/* Left: Folder, Category & Add Section */}
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center bg-white dark:bg-slate-800 rounded-2xl px-3 py-1.5 border border-slate-200/80 dark:border-slate-700">
            <Folder className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400 mr-1.5 shrink-0" />
            <select
              value={folderId}
              onChange={(e) => setFolderId(e.target.value)}
              aria-label="Select Folder"
              className="text-xs font-medium text-slate-700 dark:text-slate-200 bg-transparent focus:outline-none cursor-pointer"
            >
              {folders.map((f) => (
                <option key={f.id} value={f.id} className="bg-white dark:bg-slate-800">
                  {f.name.split(' (')[0]}
                </option>
              ))}
            </select>
          </div>

          <div className="flex items-center bg-white dark:bg-slate-800 rounded-2xl px-3 py-1.5 border border-slate-200/80 dark:border-slate-700">
            <Tag className="h-3.5 w-3.5 text-emerald-600 dark:text-emerald-400 mr-1.5 shrink-0" />
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              aria-label="Select Category"
              className="text-xs font-medium text-slate-700 dark:text-slate-200 bg-transparent focus:outline-none cursor-pointer"
            >
              {DEFAULT_CATEGORIES.filter((c) => c !== 'সব নোট (All)').map((cat) => (
                <option key={cat} value={cat} className="bg-white dark:bg-slate-800">
                  {cat.split(' (')[0]}
                </option>
              ))}
            </select>
          </div>

          {/* Add Section Button */}
          <button
            type="button"
            onClick={handleAddSection}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-xs font-bold transition-all cursor-pointer"
            title="এই নোটের মধ্যে আরেকটি নতুন অধ্যায়/অংশ যোগ করুন"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>+ নতুন অংশ যোগ করুন</span>
          </button>
        </div>

        {/* Right: Full Copy, Reading Mode, Save, Pin, Fav */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Requirement: Full Note Copy includes Section Titles! */}
          <button
            type="button"
            onClick={handleCopyFullNoteWithSectionTitles}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-2xl text-xs font-bold transition-all active:scale-95 cursor-pointer ${
              copiedFullNote
                ? 'bg-indigo-600 text-white'
                : 'bg-slate-900 dark:bg-slate-800 text-white hover:bg-slate-800'
            }`}
            title="অধ্যায়ের নামসহ পুরো নোট একসাথে কপি করুন"
          >
            {copiedFullNote ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
            <span>{copiedFullNote ? 'অধ্যায়সহ কপিড!' : 'পুরো নোট কপি (অধ্যায়সহ)'}</span>
          </button>

          {/* Reading Mode */}
          <button
            type="button"
            onClick={() => {
              if (onSwitchToReadingMode) {
                onSwitchToReadingMode();
              } else {
                setReadingModalOpen(true);
              }
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-100 dark:hover:bg-indigo-900 text-indigo-700 dark:text-indigo-300 text-xs font-bold transition-all cursor-pointer"
            title="রিডিং মোড (পড়ুন)"
          >
            <BookOpen className="h-3.5 w-3.5 text-indigo-600 dark:text-indigo-400" />
            <span>রিডিং মোড (পড়ুন)</span>
          </button>

          {/* Explicit Save Button */}
          <button
            type="button"
            onClick={handleSaveClick}
            disabled={isSaving}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-xs transition-all active:scale-95 cursor-pointer disabled:opacity-50"
            title="নোট সেভ করুন"
          >
            {savedFeedback ? <Check className="h-3.5 w-3.5" /> : <Save className="h-3.5 w-3.5" />}
            <span>{savedFeedback ? 'সেভ হয়েছে!' : 'নোট সেভ করুন (Save)'}</span>
          </button>

          {/* Pin & Favorite */}
          <button
            type="button"
            onClick={() => setIsPinned(!isPinned)}
            className={`p-2 rounded-2xl transition-colors cursor-pointer ${
              isPinned
                ? 'bg-amber-100 dark:bg-amber-950/70 text-amber-600 dark:text-amber-400'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600'
            }`}
            title="পিন করুন"
          >
            <Pin className="h-3.5 w-3.5" />
          </button>

          <button
            type="button"
            onClick={() => setIsFavorite(!isFavorite)}
            className={`p-2 rounded-2xl transition-colors cursor-pointer ${
              isFavorite
                ? 'bg-rose-100 dark:bg-rose-950/70 text-rose-600 dark:text-rose-400'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-slate-600'
            }`}
            title="ফেভারিট করুন"
          >
            <Star className={`h-3.5 w-3.5 ${isFavorite ? 'fill-rose-500' : ''}`} />
          </button>

          <button
            type="button"
            onClick={() =>
              exportNoteToPrint({
                ...note,
                title,
                content: combineSectionsToContent(sections),
                sections,
                category,
              })
            }
            className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-300 transition-colors cursor-pointer"
            title="প্রিন্ট বা PDF হিসেবে সেভ"
          >
            <Download className="h-3.5 w-3.5" />
          </button>

          {onDelete && !isNewDraft && (
            <button
              type="button"
              onClick={() => onDelete(note.id)}
              className="p-2 rounded-2xl bg-slate-100 dark:bg-slate-800 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors cursor-pointer"
              title="নোট মুছে ফেলুন"
            >
              <Trash2 className="h-3.5 w-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Formatting & Voice Ribbon */}
      <div className="px-4 sm:px-6 py-2 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2 bg-white dark:bg-slate-900">
        <div className="flex flex-wrap items-center gap-1">
          <button
            type="button"
            onClick={() => insertFormatting('**', '**', 'গাঢ় লেখা')}
            className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Bold"
          >
            <Bold className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertFormatting('*', '*', 'বাঁকা লেখা')}
            className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Italic"
          >
            <Italic className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertFormatting('\n### ', '', 'শিরোনাম')}
            className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Heading"
          >
            <Heading2 className="h-4 w-4" />
          </button>
          <button
            type="button"
            onClick={() => insertFormatting('\n• ', '', 'পয়েন্ট')}
            className="p-1.5 rounded-xl text-slate-500 hover:text-slate-900 dark:text-slate-400 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            title="Bullet Point"
          >
            <List className="h-4 w-4" />
          </button>

          <div className="h-4 w-px bg-slate-200 dark:bg-slate-700 mx-1" />

          <button
            type="button"
            onClick={() =>
              insertFormatting(
                '\n```javascript\n',
                '\n```\n',
                'function calculate(x) {\n  return x * 2;\n}'
              )
            }
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            title="কোড ব্লক"
          >
            <Code2 className="h-3.5 w-3.5 text-indigo-500" />
            <span>কোড</span>
          </button>

          <button
            type="button"
            onClick={() =>
              insertFormatting(
                '\n| বিষয় | বিবরণ | স্ট্যাটাস |\n| :--- | :--- | :--- |\n| আইটেম ১ | তথ্য এ | সক্রিয় |\n| আইটেম ২ | তথ্য বি | রেডি |\n'
              )
            }
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            title="টেবিল"
          >
            <TableIcon className="h-3.5 w-3.5 text-emerald-500" />
            <span>টেবিল</span>
          </button>

          <button
            type="button"
            onClick={() => insertFormatting('\n$$\n', '\n$$\n', 'x = \\frac{-b \\pm \\sqrt{b^2 - 4ac}}{2a}')}
            className="flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            title="ম্যাথ সূত্র"
          >
            <Sigma className="h-3.5 w-3.5 text-purple-500" />
            <span>গণিত</span>
          </button>

          <button
            type="button"
            onClick={() => setShowSymbols(!showSymbols)}
            className={`flex items-center gap-1 px-2 py-1 rounded-xl text-xs font-medium cursor-pointer ${
              showSymbols ? 'bg-amber-500 text-white' : 'text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800'
            }`}
          >
            <Sparkles className="h-3.5 w-3.5 text-amber-500" />
            <span>প্রতীক</span>
          </button>

          {/* Voice Typing */}
          <div className="flex items-center bg-slate-100 dark:bg-slate-800 p-0.5 rounded-xl ml-1">
            <button
              type="button"
              onClick={handleToggleVoiceTyping}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isListening
                  ? 'bg-rose-600 text-white animate-pulse'
                  : 'text-slate-600 dark:text-slate-300 hover:text-slate-900'
              }`}
              title="মুখে বলে লিখুন (ভয়েস টাইপিং)"
            >
              {isListening ? <MicOff className="h-3.5 w-3.5" /> : <Mic className="h-3.5 w-3.5 text-rose-500" />}
              <span>{isListening ? 'শুনছি...' : 'ভয়েস'}</span>
            </button>
            <button
              type="button"
              onClick={() => setVoiceLang(voiceLang === 'bn-BD' ? 'en-US' : 'bn-BD')}
              className="px-1.5 py-0.5 text-[10px] font-bold text-slate-500 hover:text-indigo-600 cursor-pointer"
            >
              {voiceLang === 'bn-BD' ? 'BN' : 'EN'}
            </button>
          </div>
        </div>

        <div className="text-xs text-slate-400 tabular-nums">
          মোট অধ্যায়: {sections.length} টি
        </div>
      </div>

      {/* Expandable Math & Unicode Symbols Bar */}
      {showSymbols && (
        <div className="px-4 sm:px-6 py-2 bg-slate-50 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center gap-1">
          {UNICODE_MATH_SYMBOLS.map((sym) => (
            <button
              key={sym}
              type="button"
              onClick={() => insertFormatting(sym, '', '')}
              className="h-7 w-7 rounded-lg bg-white dark:bg-slate-900 hover:bg-indigo-600 hover:text-white text-slate-700 dark:text-slate-200 font-mono text-xs font-semibold border border-slate-200 dark:border-slate-700 flex items-center justify-center transition-colors cursor-pointer"
            >
              {sym}
            </button>
          ))}
        </div>
      )}

      {/* Note Main Title */}
      <div className="px-5 sm:px-8 pt-5 pb-3 border-b border-slate-100 dark:border-slate-800/80">
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="নোটের মূল শিরোনাম বা নাম লিখুন..."
          className={`w-full text-xl sm:text-2xl md:text-3xl font-extrabold text-slate-900 dark:text-white bg-transparent focus:outline-none placeholder:text-slate-300 dark:placeholder:text-slate-600 ${fontClasses}`}
        />
      </div>

      {/* Multiple Sections Container */}
      <div className="flex-1 p-4 sm:p-7 space-y-5 bg-slate-50/40 dark:bg-slate-950/20">
        {sections.map((sec, idx) => {
          const isPreview = Boolean(sectionPreviewMap[sec.id]);
          const isCopiedThisSec = copiedSingleSecId === sec.id;
          const isFocusedSec = activeSectionId === sec.id;

          return (
            <div
              key={sec.id}
              onClick={() => setActiveSectionId(sec.id)}
              className={`rounded-2xl bg-white dark:bg-slate-900 border transition-all overflow-hidden ${
                isFocusedSec
                  ? 'border-indigo-500/80 dark:border-indigo-500/70 shadow-xs'
                  : 'border-slate-200/80 dark:border-slate-800'
              }`}
            >
              {/* Section Header */}
              <div className="px-4 sm:px-5 py-2.5 bg-slate-50/80 dark:bg-slate-800/60 border-b border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2 flex-1 min-w-[200px]">
                  <span className="inline-flex items-center justify-center h-6 w-6 rounded-lg bg-indigo-50 dark:bg-indigo-950 text-indigo-600 dark:text-indigo-400 text-xs font-bold tabular-nums shrink-0">
                    {idx + 1}
                  </span>
                  <input
                    type="text"
                    value={sec.title}
                    onChange={(e) => handleUpdateSection(sec.id, 'title', e.target.value)}
                    placeholder={`অধ্যায় ${idx + 1}-এর নাম লিখুন...`}
                    className="w-full text-sm font-bold text-slate-800 dark:text-slate-100 bg-transparent focus:outline-none placeholder:text-slate-400"
                  />
                </div>

                {/* Section Action Buttons */}
                <div className="flex items-center gap-1.5">
                  {/* Requirement:
                      "প্রতিটা অংশ আলাদা আলাদা ভাবে কপি করার ক্ষেত্রে অধ্যায়ের নাম সহ কপি করা দরকার নাই শুধুমাত্র কনটেন্ট কপি করলেই হবে।"
                  */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleCopySingleSectionContentOnly(sec);
                    }}
                    className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 cursor-pointer whitespace-nowrap ${
                      isCopiedThisSec
                        ? 'bg-emerald-600 text-white'
                        : 'bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-600 hover:text-white text-indigo-700 dark:text-indigo-300'
                    }`}
                    title="এই অধ্যায়ের নাম ছাড়া শুধুমাত্র লেখা কপি করুন"
                  >
                    {isCopiedThisSec ? (
                      <>
                        <Check className="h-3.5 w-3.5" />
                        <span>লেখা কপিড!</span>
                      </>
                    ) : (
                      <>
                        <Copy className="h-3.5 w-3.5" />
                        <span>অংশ কপি (নাম ছাড়া)</span>
                      </>
                    )}
                  </button>

                  {/* Edit vs Preview Toggle for this section */}
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      setSectionPreviewMap((prev) => ({
                        ...prev,
                        [sec.id]: !prev[sec.id],
                      }));
                    }}
                    className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      isPreview
                        ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900'
                        : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-300 hover:bg-slate-200'
                    }`}
                  >
                    {isPreview ? (
                      <>
                        <Edit3 className="h-3.5 w-3.5" />
                        <span>এডিট</span>
                      </>
                    ) : (
                      <>
                        <Eye className="h-3.5 w-3.5" />
                        <span>প্রিভিউ</span>
                      </>
                    )}
                  </button>

                  {sections.length > 1 && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDeleteSection(sec.id);
                      }}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors cursor-pointer"
                      title="এই অংশটি বাদ দিন"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>

              {/* Section Body: Edit Mode vs Markdown Preview Mode */}
              {isPreview ? (
                /* Requirement:
                   "এডিট মোডে আমি যদি কোন স্পেস তারপরে পয়েন্ট করে কোন কিছু লিখি সেটা প্রিভিউ মোডে গিয়ে মাঝখানের স্পেস গুলা হারায়ে যায় তখন দেখতে ভালো লাগে না আমি চাই এডিট মোটেই যেরকম ভাবে আমি সেটাকে লিখার চেষ্টা করব প্রিভিউতে যেন সেরকম ভাবেও দেখা যায় অর্থাৎ স্পেস পয়েন্ট যেভাবে লিখব সেভাবে দেখা যাবে।"
                */
                <div className={`p-5 markdown-content text-base text-slate-800 dark:text-slate-200 ${fontClasses}`}>
                  <Markdown
                    remarkPlugins={[remarkGfm, remarkBreaks, remarkMath]}
                    rehypePlugins={[rehypeKatex]}
                    components={{
                      code(props) {
                        const { children, className, ...rest } = props;
                        const match = /language-(\w+)/.exec(className || '');
                        const codeString = String(children).replace(/\n$/, '');
                        const isBlock = Boolean(match || codeString.includes('\n'));

                        if (isBlock) {
                          const lang = match ? match[1] : 'code';
                          const blockKey = `${sec.id}-${codeString.slice(0, 20)}`;
                          return (
                            <div className="my-3 rounded-2xl overflow-hidden bg-slate-950 text-slate-100 border border-slate-800">
                              <div className="flex items-center justify-between px-4 py-2 bg-slate-900 border-b border-slate-800 text-xs">
                                <span className="font-mono text-indigo-400 uppercase font-semibold">
                                  {lang}
                                </span>
                                <button
                                  type="button"
                                  onClick={async () => {
                                    await navigator.clipboard.writeText(codeString);
                                    setCopiedCodeSnippet(blockKey);
                                    setTimeout(() => setCopiedCodeSnippet(null), 2000);
                                  }}
                                  className="flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-white/10 hover:bg-white/20 text-white text-[11px] font-medium transition-colors cursor-pointer"
                                >
                                  {copiedCodeSnippet === blockKey ? (
                                    <>
                                      <Check className="h-3 w-3 text-emerald-400" />
                                      <span>কপিড!</span>
                                    </>
                                  ) : (
                                    <>
                                      <Copy className="h-3 w-3" />
                                      <span>কোড কপি</span>
                                    </>
                                  )}
                                </button>
                              </div>
                              <pre className="p-4 overflow-x-auto text-xs sm:text-sm font-mono leading-relaxed m-0">
                                <code className={className} {...rest}>
                                  {children}
                                </code>
                              </pre>
                            </div>
                          );
                        }
                        return (
                          <code
                            className="px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-slate-800 text-indigo-600 dark:text-indigo-400 font-mono text-[0.9em]"
                            {...rest}
                          >
                            {children}
                          </code>
                        );
                      },
                      table({ children }) {
                        return (
                          <div className="my-3 overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-800">
                            <table>{children}</table>
                          </div>
                        );
                      },
                    }}
                  >
                    {sec.content || '*এই অংশে এখনো কিছু লেখা হয়নি...*'}
                  </Markdown>
                </div>
              ) : (
                <div className="p-4 sm:p-5">
                  <textarea
                    ref={(el) => {
                      textareaRefs.current[sec.id] = el;
                    }}
                    value={sec.content}
                    onFocus={() => setActiveSectionId(sec.id)}
                    onChange={(e) => handleUpdateSection(sec.id, 'content', e.target.value)}
                    placeholder="এই অংশে আপনার পয়েন্ট, নোট, কোড কিংবা সূত্র লিখুন (যেভাবে স্পেস ও পয়েন্ট দিবেন তা অক্ষত থাকবে)..."
                    rows={sections.length === 1 ? 10 : 5}
                    className={`w-full resize-y bg-transparent text-slate-800 dark:text-slate-100 focus:outline-none leading-relaxed text-base whitespace-pre-wrap ${fontClasses}`}
                  />
                </div>
              )}
            </div>
          );
        })}

        {/* Add Another Section Button */}
        <div className="pt-2 flex flex-wrap items-center justify-between gap-3">
          <button
            type="button"
            onClick={handleAddSection}
            className="flex items-center gap-2 px-4 py-2.5 rounded-2xl border border-dashed border-indigo-400 dark:border-indigo-800 hover:border-indigo-600 bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-400 text-xs font-bold transition-all cursor-pointer shadow-2xs"
          >
            <Layers className="h-4 w-4" />
            <span>+ নতুন আরেকটি অধ্যায় বা অংশ তৈরি করুন (Add Section)</span>
          </button>

          <button
            type="button"
            onClick={handleSaveClick}
            disabled={isSaving}
            className="flex items-center gap-2 px-6 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold shadow-xs transition-all active:scale-95 cursor-pointer disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            <span>নোট সেভ করুন (Save Note)</span>
          </button>
        </div>
      </div>

      {/* Footer Meta */}
      <div className="px-5 sm:px-8 py-3.5 border-t border-slate-100 dark:border-slate-800/80 bg-slate-50/40 dark:bg-slate-900/40 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-500 dark:text-slate-400 tabular-nums">
        <div className="flex items-center gap-2">
          <span>মোট অধ্যায়: {sections.length} টি</span>
          <span>•</span>
          <span>মোট শব্দ: {totalWords}</span>
          <span>•</span>
          <span>~{Math.max(1, Math.ceil(totalWords / 180))} মিনিট পাঠ</span>
        </div>
        <div>{isSaving ? 'ক্লাউডে সেভ হচ্ছে...' : lastSavedText}</div>
      </div>

      {/* Full Screen Reading Mode */}
      <ReadingModeModal
        note={{
          ...note,
          title,
          content: combineSectionsToContent(sections),
          sections,
          category,
        }}
        isOpen={readingModalOpen}
        onClose={() => setReadingModalOpen(false)}
      />
    </div>
  );
}
