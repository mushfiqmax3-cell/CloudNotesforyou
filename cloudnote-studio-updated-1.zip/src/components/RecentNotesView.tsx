import React, { useState } from 'react';
import {
  Search,
  X,
  Copy,
  Check,
  Pin,
  Star,
  Trash2,
  Clock,
  Printer,
  ChevronRight,
  BookOpen,
  Layers,
  Edit3,
} from 'lucide-react';
import { NoteItem, FolderItem, getNormalizedSections } from '../lib/types';
import { exportNoteToPrint } from '../lib/pdf-export';

interface RecentNotesViewProps {
  notes: NoteItem[];
  folders: FolderItem[];
  defaultFilter?: 'all' | 'pinned' | 'favorite';
  onSelectNote: (note: NoteItem) => void;
  onEditNote?: (note: NoteItem) => void;
  onDeleteNote: (id: string) => void;
  onToggleFavorite: (note: NoteItem) => void;
  onOpenReadingMode: (note: NoteItem) => void;
}

export function RecentNotesView({
  notes,
  folders,
  defaultFilter = 'all',
  onSelectNote,
  onEditNote,
  onDeleteNote,
  onToggleFavorite,
  onOpenReadingMode,
}: RecentNotesViewProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<'all' | 'pinned' | 'favorite'>(defaultFilter);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Sync default filter if passed
  React.useEffect(() => {
    setFilterType(defaultFilter);
  }, [defaultFilter]);

  // Requirement: Copy ONLY the content under the note, without title!
  const handleCopyNoteContentOnly = async (e: React.MouseEvent, note: NoteItem) => {
    e.stopPropagation();
    const sections = getNormalizedSections(note);
    const contentOnly = sections.map((s) => s.content).join('\n\n');
    try {
      await navigator.clipboard.writeText(contentOnly || note.content || '');
      setCopiedId(note.id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = contentOnly || note.content || '';
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedId(note.id);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  // Requirement: Copy full note WITH section/chapter titles!
  const handleCopyNoteWithSectionTitles = async (e: React.MouseEvent, note: NoteItem) => {
    e.stopPropagation();
    const sections = getNormalizedSections(note);
    const withTitles = sections
      .map((s, idx) => `[${s.title || `অধ্যায় ${idx + 1}`}]\n${s.content}`)
      .join('\n\n---\n\n');

    try {
      await navigator.clipboard.writeText(withTitles);
      setCopiedId(`full_${note.id}`);
      setTimeout(() => setCopiedId(null), 2000);
    } catch {
      const el = document.createElement('textarea');
      el.value = withTitles;
      document.body.appendChild(el);
      el.select();
      document.execCommand('copy');
      document.body.removeChild(el);
      setCopiedId(`full_${note.id}`);
      setTimeout(() => setCopiedId(null), 2000);
    }
  };

  const filteredNotes = notes
    .filter((note) => {
      if (filterType === 'pinned' && !note.isPinned) return false;
      if (filterType === 'favorite' && !note.isFavorite) return false;
      if (!searchQuery.trim()) return true;

      const q = searchQuery.toLowerCase();
      const inTitle = (note.title || '').toLowerCase().includes(q);
      const inContent = (note.content || '').toLowerCase().includes(q);
      const inCategory = (note.category || '').toLowerCase().includes(q);
      const inSections = (note.sections || []).some(
        (s) => s.title.toLowerCase().includes(q) || s.content.toLowerCase().includes(q)
      );
      const folderName = folders.find((f) => f.id === note.folderId)?.name.toLowerCase() || '';
      const inFolder = folderName.includes(q);
      return inTitle || inContent || inCategory || inSections || inFolder;
    })
    .sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      return b.updatedAt - a.updatedAt;
    });

  return (
    <div className="space-y-4">
      {/* Search Header Container - Note: NO autoFocus on the input! */}
      <div className="rounded-3xl bg-white dark:bg-slate-900 p-4 sm:p-6 border border-slate-200/80 dark:border-slate-800 shadow-sm space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
          <div>
            <h2 className="text-lg sm:text-xl font-bold text-slate-900 dark:text-white">
              {filterType === 'favorite'
                ? '⭐ ফেভারিট নোটসমূহ (Favorite Notes)'
                : 'রিসেন্ট সেভ করা নোটসমূহ (Recent Notes)'}
            </h2>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              সার্চ অপশনে ক্লিক করলে কিবোর্ড আসবে। মাঝারি সাইজের কার্ডে এক স্ক্রিনে অনেক নোট দেখতে পাবেন।
            </p>
          </div>
          <div className="flex items-center gap-1.5 self-start sm:self-auto text-xs font-semibold px-3 py-1 rounded-2xl bg-indigo-50 dark:bg-indigo-950/70 text-indigo-700 dark:text-indigo-300 tabular-nums">
            মোট {filteredNotes.length} টি নোট
          </div>
        </div>

        {/* Search Input Bar - autoFocus is explicitly omitted so mobile keyboard only appears when clicked! */}
        <div className="relative">
          <Search className="h-4 w-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="নোটের নাম, অধ্যায়, ভেতরের লেখা বা ক্যাটাগরি দিয়ে খুঁজুন..."
            className="w-full pl-10 pr-9 py-2.5 sm:py-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200/80 dark:border-slate-700 text-xs sm:text-sm text-slate-900 dark:text-white placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-indigo-600 focus:bg-white dark:focus:bg-slate-900 transition-all"
          />
          {searchQuery && (
            <button
              type="button"
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-1"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        {/* Filter Pills with prominent Favorite option */}
        <div className="flex flex-wrap items-center gap-2 pt-0.5">
          <button
            type="button"
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'all'
                ? 'bg-slate-900 dark:bg-indigo-600 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            সবগুলো ({notes.length})
          </button>
          <button
            type="button"
            onClick={() => setFilterType('favorite')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'favorite'
                ? 'bg-rose-500 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            <Star className="h-3.5 w-3.5 fill-current" />
            <span>ফেভারিট ({notes.filter((n) => n.isFavorite).length})</span>
          </button>
          <button
            type="button"
            onClick={() => setFilterType('pinned')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              filterType === 'pinned'
                ? 'bg-amber-500 text-white'
                : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
            }`}
          >
            <Pin className="h-3.5 w-3.5 fill-current" />
            <span>পিন করা ({notes.filter((n) => n.isPinned).length})</span>
          </button>
        </div>
      </div>

      {/* Medium-Sized / Compact Notes Grid:
          Requirement: "রিসেন্ট অপশনে থাকা নোটগুলোকে একটু মাঝারি করে দেখাবে যেন এক স্ক্রিনে অনেক গুলো স্ক্রিনে দেখতে পাই।"
      */}
      {filteredNotes.length === 0 ? (
        <div className="rounded-3xl bg-white dark:bg-slate-900 p-10 text-center border border-slate-200/80 dark:border-slate-800 space-y-2.5">
          <Clock className="h-8 w-8 text-slate-300 dark:text-slate-600 mx-auto" />
          <h3 className="text-sm font-bold text-slate-700 dark:text-slate-300">
            কোনো নোট খুঁজে পাওয়া যায়নি
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            অন্য কোনো শব্দ লিখে সার্চ করুন অথবা নতুন নোট তৈরি করতে উপরের বাটনে ক্লিক করুন।
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filteredNotes.map((item) => {
            const folderName =
              folders.find((f) => f.id === item.folderId)?.name.split(' (')[0] || 'সাধারণ';
            const itemSections = getNormalizedSections(item);
            const isContentCopied = copiedId === item.id;
            const isFullCopied = copiedId === `full_${item.id}`;

            return (
              <div
                key={item.id}
                onClick={() => onSelectNote(item)}
                className="group rounded-2xl bg-white dark:bg-slate-900 p-3.5 sm:p-4 border border-slate-200/80 dark:border-slate-800 hover:border-indigo-500/70 shadow-2xs hover:shadow-sm transition-all cursor-pointer flex flex-col justify-between space-y-3"
              >
                {/* Header & Badges */}
                <div className="space-y-1.5">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-1">
                      {item.title || 'শিরোনামহীন নোট'}
                    </h3>
                    <div className="flex items-center gap-1 shrink-0">
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onToggleFavorite(item);
                        }}
                        className="p-1 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-400 hover:text-rose-500 transition-colors"
                        title={item.isFavorite ? 'ফেভারিট থেকে সরান' : 'ফেভারিট করুন'}
                      >
                        <Star
                          className={`h-3.5 w-3.5 ${
                            item.isFavorite ? 'text-rose-500 fill-rose-500' : ''
                          }`}
                        />
                      </button>
                      {item.isPinned && (
                        <span title="পিন করা">
                          <Pin className="h-3.5 w-3.5 text-amber-500 fill-amber-500" />
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Section count & Category tags */}
                  <div className="flex flex-wrap items-center gap-1.5 text-[11px] text-slate-500 dark:text-slate-400">
                    <span className="px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-950/80 text-indigo-600 dark:text-indigo-400 font-semibold flex items-center gap-1">
                      <Layers className="h-2.5 w-2.5" />
                      <span>{itemSections.length} অধ্যায়</span>
                    </span>
                    <span>•</span>
                    <span className="truncate max-w-[85px]">{folderName}</span>
                    <span>•</span>
                    <span className="tabular-nums">
                      {new Date(item.updatedAt).toLocaleDateString('bn-BD')}
                    </span>
                  </div>

                  {/* Concise Snippet Preview */}
                  <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-2 leading-relaxed whitespace-pre-wrap">
                    {itemSections[0]?.content || item.content || '(কোনো লেখা নেই)'}
                  </p>
                </div>

                {/* Compact Card Actions */}
                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex flex-wrap items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1">
                    {/* Read Full Screen */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onOpenReadingMode(item);
                      }}
                      className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 hover:bg-indigo-600 hover:text-white text-slate-600 dark:text-slate-300 transition-colors"
                      title="ফুল-স্ক্রিন পড়ার মোড"
                    >
                      <BookOpen className="h-3.5 w-3.5" />
                    </button>

                    {/* Copy Content Only (without title) */}
                    <button
                      type="button"
                      onClick={(e) => handleCopyNoteContentOnly(e, item)}
                      className={`flex items-center gap-1 px-2 py-1 rounded-lg text-[11px] font-bold transition-all active:scale-95 cursor-pointer ${
                        isContentCopied
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 text-slate-700 dark:text-slate-200'
                      }`}
                      title="নাম ছাড়া শুধু কনটেন্ট কপি করুন"
                    >
                      {isContentCopied ? (
                        <>
                          <Check className="h-3 w-3" />
                          <span>কপিড!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="h-3 w-3" />
                          <span>লেখা কপি</span>
                        </>
                      )}
                    </button>

                    {/* Copy full note with section titles */}
                    {itemSections.length > 1 && (
                      <button
                        type="button"
                        onClick={(e) => handleCopyNoteWithSectionTitles(e, item)}
                        className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition-all active:scale-95 cursor-pointer ${
                          isFullCopied
                            ? 'bg-indigo-600 text-white'
                            : 'bg-indigo-50 dark:bg-indigo-950/70 hover:bg-indigo-100 text-indigo-700 dark:text-indigo-300'
                        }`}
                        title="অধ্যায়সহ পুরোটা কপি করুন"
                      >
                        {isFullCopied ? 'সব কপিড!' : 'অধ্যায়সহ'}
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-0.5">
                    {/* Direct Edit Button */}
                    {onEditNote && (
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          onEditNote(item);
                        }}
                        className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-950/60 transition-colors"
                        title="নোটটি এডিট করুন"
                      >
                        <Edit3 className="h-3.5 w-3.5" />
                      </button>
                    )}

                    {/* Print / PDF */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        exportNoteToPrint(item);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                      title="প্রিন্ট / PDF"
                    >
                      <Printer className="h-3.5 w-3.5" />
                    </button>

                    {/* Delete */}
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onDeleteNote(item.id);
                      }}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/50 transition-colors"
                      title="মুছে ফেলুন"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>

                    <ChevronRight className="h-3.5 w-3.5 text-slate-300 group-hover:text-indigo-500 transition-colors" />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
