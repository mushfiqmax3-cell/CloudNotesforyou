export type FontFamilyOption = 'sans' | 'serif' | 'mono' | 'noto-sans-bengali' | 'solaiman-lipi' | 'kalpurush' | 'hind-siliguri' | 'noto-serif-bengali' | 'tiro-bangla' | 'georgia' | 'times-new-roman';

export interface NoteSection {
  id: string;
  title: string;
  content: string;
}

export interface NoteItem {
  id: string;
  userId: string;
  title: string;
  content: string; // The combined note text for search & backward compatibility
  sections?: NoteSection[]; // Multiple chapters/sections within a single note
  category: string;
  folderId: string;
  isPinned: boolean;
  isFavorite: boolean;
  tags?: string[];
  createdAt: number;
  updatedAt: number;
  synced?: boolean;
}

export interface FolderItem {
  id: string;
  userId: string;
  name: string;
  color: 'emerald' | 'rose' | 'amber' | 'purple' | 'blue';
  createdAt: number;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  creationTime?: string;
  lastSignInTime?: string;
  phoneNumber?: string | null;
}

export const DEFAULT_CATEGORIES = [
  'সব নোট (All)',
  'ব্যক্তিগত (Personal)',
  'কাজ ও প্রজেক্ট (Work)',
  'কোড ও প্রোগ্রামিং (Code)',
  'গণিত ও সূত্র (Math)',
  'আইডিয়া (Ideas)',
  'পড়াশোনা (Study)',
];

export const DEFAULT_FOLDERS: FolderItem[] = [
  { id: 'general', userId: 'default', name: 'সাধারণ (General)', color: 'blue', createdAt: 1700000000000 },
  { id: 'coding', userId: 'default', name: 'কোড ও ডেভেলপিং (Code)', color: 'emerald', createdAt: 1700000001000 },
  { id: 'math-science', userId: 'default', name: 'গণিত ও বিজ্ঞান (Math)', color: 'purple', createdAt: 1700000002000 },
  { id: 'important', userId: 'default', name: 'জরুরি নোট (Important)', color: 'rose', createdAt: 1700000003000 },
  { id: 'journal', userId: 'default', name: 'দৈনিক ডায়েরি (Journal)', color: 'amber', createdAt: 1700000004000 },
];

export function getNormalizedSections(note: NoteItem): NoteSection[] {
  if (Array.isArray(note.sections) && note.sections.length > 0) {
    return note.sections;
  }
  return [
    {
      id: 'sec_1',
      title: '১ম অধ্যায় / মূল অংশ',
      content: note.content || '',
    },
  ];
}

export function combineSectionsToContent(sections: NoteSection[]): string {
  return sections
    .map((sec) => (sec.title ? `### ${sec.title}\n${sec.content}` : sec.content))
    .join('\n\n---\n\n');
}

export const INITIAL_DEMO_NOTES: NoteItem[] = [
  {
    id: 'demo-welcome-note',
    userId: 'demo',
    title: 'ক্লাউডনোট স্টুডিওতে স্বাগতম',
    content: `### ১ম অধ্যায়: পরিচিতি ও ক্লাউড সিঙ্ক
এটি আপনার স্মার্ট অনলাইন ও অফলাইন ক্লাউড নোটপ্যাড। এখানে একটি নোটের মধ্যে একাধিক অংশ বা অধ্যায় যুক্ত করতে পারবেন।

---

### ২য় অধ্যায়: স্পেস ও পয়েন্ট সংরক্ষণ
এডিট মোডে আপনি যেভাবে স্পেস, লাইন ব্রেক ও পয়েন্ট দিবেন, প্রিভিউতেও হুবহু সেভাবে দেখা যাবে।
  • পয়েন্ট ১: স্পেস সংরক্ষিত থাকে
  • পয়েন্ট ২: যে কোনো ফোন থেকে সিঙ্ক হয়

---

### ৩য় অধ্যায়: কোড ব্লক ও টেবিল
\`\`\`javascript
function calculateSum(a, b) {
  return a + b;
}
console.log("যোগফল:", calculateSum(15, 25));
\`\`\`

| বিষয় | মান | স্ট্যাটাস |
| :--- | :--- | :--- |
| ক্লাউড সিঙ্ক | অনলাইন | সক্রিয় |
| রিডিং মোড | ফুল-স্ক্রিন | রেডি |`,
    sections: [
      {
        id: 'sec_1',
        title: '১ম অধ্যায়: পরিচিতি ও ক্লাউড সিঙ্ক',
        content: `এটি আপনার স্মার্ট অনলাইন ও অফলাইন ক্লাউড নোটপ্যাড। এখানে একটি নোটের মধ্যে একাধিক অংশ বা অধ্যায় যুক্ত করতে পারবেন। যেকোনো ডিভাইস থেকে লগইন করলেই আপনার নোট পাওয়া যাবে।`,
      },
      {
        id: 'sec_2',
        title: '২য় অধ্যায়: স্পেস ও পয়েন্ট সংরক্ষণ',
        content: `এডিট মোডে আপনি যেভাবে স্পেস, লাইন ব্রেক ও পয়েন্ট দিবেন, প্রিভিউতেও হুবহু সেভাবে দেখা যাবে।
  • পয়েন্ট ১: স্পেস সংরক্ষিত থাকে
  • পয়েন্ট ২: যে কোনো ফোন থেকে সিঙ্ক হয়
  • পয়েন্ট ৩: অধ্যায় আলাদা কপি করা যায়`,
      },
      {
        id: 'sec_3',
        title: '৩য় অধ্যায়: কোড ব্লক ও টেবিল',
        content: `\`\`\`javascript
function calculateSum(a, b) {
  return a + b;
}
console.log("যোগফল:", calculateSum(15, 25));
\`\`\`

| বিষয় | মান | স্ট্যাটাস |
| :--- | :--- | :--- |
| ক্লাউড সিঙ্ক | অনলাইন | সক্রিয় |
| রিডিং মোড | ফুল-স্ক্রিন | রেডি |`,
      },
    ],
    category: 'ব্যক্তিগত (Personal)',
    folderId: 'general',
    isPinned: true,
    isFavorite: true,
    tags: ['welcome', 'guide'],
    createdAt: Date.now() - 3600000 * 2,
    updatedAt: Date.now() - 3600000 * 2,
    synced: true,
  },
];
