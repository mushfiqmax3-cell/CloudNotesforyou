import { NoteItem } from './types';

export function exportNoteToPrint(note: NoteItem) {
  if (typeof window === 'undefined') return;

  const printWindow = window.open('', '_blank', 'width=900,height=700');
  if (!printWindow) {
    alert('প্রিন্ট পপ-আপ চালু করার অনুমতি দিন।');
    return;
  }

  // Escape HTML characters in title and content for safe rendering
  const escapeHtml = (text: string) => {
    return text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  };

  printWindow.document.write(`
    <!DOCTYPE html>
    <html lang="bn">
      <head>
        <meta charset="UTF-8" />
        <title>${escapeHtml(note.title || 'নোট প্রিন্ট')}</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/katex@0.16.11/dist/katex.min.css" />
        <style>
          body {
            font-family: system-ui, -apple-system, 'Segoe UI', Roboto, sans-serif;
            color: #0f172a;
            line-height: 1.7;
            padding: 40px;
            max-width: 800px;
            margin: 0 auto;
          }
          .header {
            border-bottom: 2px solid #e2e8f0;
            padding-bottom: 16px;
            margin-bottom: 24px;
          }
          h1 {
            font-size: 26px;
            margin: 0 0 8px 0;
            color: #0f172a;
          }
          .meta {
            font-size: 13px;
            color: #64748b;
          }
          .content {
            white-space: pre-wrap;
            word-break: break-word;
            font-size: 15px;
          }
          @media print {
            body { padding: 20px; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>${escapeHtml(note.title || 'শিরোনামহীন নোট')}</h1>
          <div class="meta">
            ক্যাটাগরি: ${escapeHtml(note.category)} · তারিখ: ${new Date(note.updatedAt).toLocaleString('bn-BD')}
          </div>
        </div>
        <div class="content">${escapeHtml(note.content)}</div>
        <script>
          window.onload = function() {
            setTimeout(function() {
              window.print();
            }, 300);
          };
        </script>
      </body>
    </html>
  `);
  printWindow.document.close();
}
