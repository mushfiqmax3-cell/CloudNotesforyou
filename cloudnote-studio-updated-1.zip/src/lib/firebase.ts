import { initializeApp, getApps, getApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import {
  initializeFirestore,
  persistentLocalCache,
  persistentMultipleTabManager,
  getFirestore,
  Firestore,
} from 'firebase/firestore';
import { getDatabase, Database } from 'firebase/database';

export const firebaseConfig = {
  apiKey: 'AIzaSyB7-lXxRnsf7zq-eU_-YfdIdWDv2CmfLSg',
  authDomain: 'notepad-4f026.firebaseapp.com',
  databaseURL: 'https://notepad-4f026-default-rtdb.asia-southeast1.firebasedatabase.app',
  projectId: 'notepad-4f026',
  storageBucket: 'notepad-4f026.firebasestorage.app',
  messagingSenderId: '684788854805',
  appId: '1:684788854805:web:cade6ba5f0b9878ea79e1c',
  measurementId: 'G-GN6RH6DVQD',
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);

let firestoreDb: Firestore;
try {
  firestoreDb = initializeFirestore(app, {
    localCache: persistentLocalCache({
      tabManager: persistentMultipleTabManager(),
    }),
  });
} catch {
  firestoreDb = getFirestore(app);
}

export const db = firestoreDb;

let realtimeDb: Database;
try {
  realtimeDb = getDatabase(app);
} catch {
  // fallback if needed
  realtimeDb = getDatabase(app, firebaseConfig.databaseURL);
}

export const rtdb = realtimeDb;
export default app;
