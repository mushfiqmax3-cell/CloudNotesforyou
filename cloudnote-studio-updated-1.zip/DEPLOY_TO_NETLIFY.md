# Netlify Deployment Guide & Fix for "@netlify/plugin-nextjs" Error

### আপনার এররটির মূল কারণ:
আপনার স্ক্রিনশটে স্পষ্ট দেখা যাচ্ছে:
`Plugin "@netlify/plugin-nextjs" failed`
`Error: Your publish directory does not contain expected Next.js build output.`

আপনার প্রোজেক্টের `build.command` সফলভাবে শেষ হয়েছিল, কিন্তু আপনার Netlify সাইটে স্বয়ংক্রিয়ভাবে একটি পুরনো **Next.js প্লাগইন (`@netlify/plugin-nextjs`)** চালু ছিল। আমাদের প্রোজেক্টটি একটি আধুনিক **Vite + React** প্রোজেক্ট, তাই Next.js প্লাগইনটি `.next` ফোল্ডার খুঁজতে গিয়ে এরর দিচ্ছিল।

---

### আমরা কোডে যা ফিক্স করেছি:
১. `netlify.toml`-এ `NETLIFY_NEXT_PLUGIN_SKIP = "true"` এবং `NEXT_PLUGIN_FORCE_RUN = "false"` যুক্ত করা হয়েছে, যাতে Netlify-তে আর কখনো Next.js প্লাগইন রান না হয়।
২. পুরনো `bun.lock` মুছে ফেলা হয়েছে (যার কারণে Netlify ভুল করে Next.js ভাবছিল)।
৩. সম্পূর্ণ ফ্রেশ `dist` প্রোডাকশন বিল্ড ও অ্যাসেট তৈরি করে রাখা হয়েছে।

---

### আপনার Netlify সাইটে এরর দূর করার ২টি সহজ উপায়:

#### উপায় ১: Netlify সাইটের সেটিংস থেকে Next.js প্লাগইন রিমুভ করা (বিদ্যমান সাইটের জন্য)
১. Netlify ড্যাশবোর্ডে গিয়ে আপনার সাইটে যান।
২. **Site configuration** (বা **Site settings**) -> **Build & deploy** -> **Plugins**-এ যান।
৩. সেখানে **"@netlify/plugin-nextjs"** প্লাগইনটির পাশে ৩ ডট (...) বা Options-এ ক্লিক করে **"Uninstall plugin"** বা **Remove** করে দিন।
৪. এবার জিপ ফাইলটি পুনরায় আপলোড করুন বা **Trigger deploy** দিন। সাথে সাথে সাইট সফলভাবে লাইভ হয়ে যাবে!

#### উপায় ২: নতুন সাইট হিসেবে জিপ ড্রপ করা (১ মিনিট)
১. [app.netlify.com/drop](https://app.netlify.com/drop)-এ যান।
২. ডাউনলোড করা প্রোজেক্টের জিপ ফাইলটি সরাসরি ড্রপ করুন (অথবা আনজিপ করে ভেতরের `dist` ফোল্ডারটি ড্রপ করুন)।
৩. কোনো প্রকার প্লাগইন এরর ছাড়াই সাথে সাথে সাইটটি লাইভ হয়ে যাবে।
